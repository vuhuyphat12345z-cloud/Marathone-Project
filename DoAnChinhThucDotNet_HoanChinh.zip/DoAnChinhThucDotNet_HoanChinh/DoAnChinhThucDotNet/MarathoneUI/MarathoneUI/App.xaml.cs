﻿using System.Windows;
using System.Windows.Threading;

namespace MarathoneUI
{
    /// <summary>
    /// App entry point cua ung dung WPF.
    /// File moi: truoc day du an thieu App.xaml nen khong co Application object,
    /// trong khi Program.cs (console Main) bi xoa de tranh loi CS0017 hai entry point.
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Dang ky bo bat loi toan cuc cho luong UI
            DispatcherUnhandledException += OnDispatcherUnhandledException;
        }

        /// <summary>
        /// Bat toan cuc ngoai le UI de ung dung khong bi tat dot ngot,
        /// thong bao loi (vi du khong ket noi duoc SQL Server) cho nguoi dung.
        /// </summary>
        private void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            MessageBox.Show(
                "Đã xảy ra lỗi hệ thống:\n\n" + e.Exception.Message +
                "\n\nVui lòng kiểm tra kết nối Database (server LAPTOP-J5TG78LN, CSDL DoAnDotNet - file DATACHINHTHUC.sql) và thử lại.",
                "MarathoneUI - Lỗi hệ thống",
                MessageBoxButton.OK,
                MessageBoxImage.Error);

            e.Handled = true;
        }
    }
}
