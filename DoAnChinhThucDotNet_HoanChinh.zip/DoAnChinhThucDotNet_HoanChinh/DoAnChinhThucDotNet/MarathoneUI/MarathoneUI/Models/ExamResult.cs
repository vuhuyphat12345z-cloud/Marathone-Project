﻿namespace MarathoneUI.Models
{
    /// <summary>Một dòng trong lịch sử thi của người dùng hiện tại.</summary>
    public class ExamHistoryItem
    {
        public int ExamId { get; set; }
        public DateTime StartTime { get; set; }
        public int TotalQuestions { get; set; }
        public int CorrectAnswers { get; set; }
        public double Score { get; set; }
        public bool IsCompleted { get; set; }

        /// <summary>Trạng thái hiển thị bằng tiếng Việt trên bảng lịch sử thi.</summary>
        public string IsCompletedText => IsCompleted ? "Đã nộp bài" : "Chưa nộp";
    }

    /// <summary>
    /// Một dòng lịch sử thi của TẤT CẢ sinh viên (dành cho Admin, JOIN bảng Users).
    /// </summary>
    public class AllExamHistoryItem
    {
        public int ExamId { get; set; }
        public string Username { get; set; }
        public string FullName { get; set; }
        public string ClassName { get; set; }
        public DateTime StartTime { get; set; }
        public int TotalQuestions { get; set; }
        public int CorrectAnswers { get; set; }
        public double Score { get; set; }
        public bool IsCompleted { get; set; }

        public string IsCompletedText => IsCompleted ? "Đã nộp bài" : "Chưa nộp";
        public string StudentDisplay => $"{FullName} ({Username})";
    }

    /// <summary>
    /// Chi tiết một câu hỏi trong bài thi đã nộp (cửa sổ XEM CHI TIẾT):
    /// câu hỏi, đáp án người thi đã chọn, đáp án đúng và kết quả đúng/sai.
    /// </summary>
    public class ExamReviewItem
    {
        public int QuestionId { get; set; }
        public string QuestionContent { get; set; }
        public string Topic { get; set; }
        public string BloomLevel { get; set; }
        public string SelectedAnswer { get; set; }   // null nếu bỏ trống
        public string CorrectAnswer { get; set; }
        public bool IsCorrect { get; set; }

        public string SelectedAnswerText =>
            string.IsNullOrEmpty(SelectedAnswer) ? "(Không trả lời)" : SelectedAnswer;
        public string ResultText => IsCorrect ? "ĐÚNG" : "SAI";
    }

    /// <summary>Số liệu tổng hợp cho tab THỐNG KÊ của Admin.</summary>
    public class StatisticsSummary
    {
        public int TotalAccounts { get; set; }
        public int TotalStudents { get; set; }
        public int TotalQuestions { get; set; }
        public int TotalOptions { get; set; }
        public int TotalExams { get; set; }
        public int CompletedExams { get; set; }
        public int TotalBadgesAwarded { get; set; }
        public double AverageScore { get; set; }
    }

    /// <summary>Phân bố số câu hỏi theo chủ đề.</summary>
    public class TopicDistributionItem
    {
        public string Topic { get; set; }
        public int QuestionCount { get; set; }
    }

    /// <summary>Top học viên theo điểm trung bình.</summary>
    public class TopStudentItem
    {
        public string FullName { get; set; }
        public string ClassName { get; set; }
        public int ExamCount { get; set; }
        public double BestScore { get; set; }
        public double AverageScore { get; set; }
    }
}
