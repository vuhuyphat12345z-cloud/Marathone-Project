﻿using System;

namespace MarathoneUI.Models
{
    /// <summary>Một câu hỏi trong ngân hàng câu hỏi (bảng Questions).</summary>
    public class Question
    {
        public int QuestionId { get; set; }
        public string Content { get; set; }
        public string Topic { get; set; }
        public string BloomLevel { get; set; }
        public DateTime CreatedAt { get; set; }

        /// <summary>Nội dung rút gọn để hiển thị tooltip/danh sách.</summary>
        public string ShortContent =>
            string.IsNullOrEmpty(Content) || Content.Length <= 80
                ? Content
                : Content.Substring(0, 80) + "...";
    }

    /// <summary>Một phương án của câu hỏi (bảng QuestionOptions).</summary>
    public class QuestionOption
    {
        public int OptionId { get; set; }
        public string OptionText { get; set; }
        public bool IsCorrect { get; set; }
    }
}
