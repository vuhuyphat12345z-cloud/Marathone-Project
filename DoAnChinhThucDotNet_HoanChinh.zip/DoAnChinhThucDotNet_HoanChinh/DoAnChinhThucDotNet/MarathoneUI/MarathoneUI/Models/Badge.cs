﻿using System;
using System.Windows.Media;

namespace MarathoneUI.Models
{
    /// <summary>
    /// Một huy hiệu thành tựu của sinh viên (bảng Badges + trạng thái trong
    /// UserBadges). IconKey khớp giá trị IconUrl trong CSDL:
    /// first_step / gold_score / perfect / persistent / master.
    /// </summary>
    public class BadgeItem
    {
        public int BadgeId { get; set; }
        public string BadgeName { get; set; }
        public string Description { get; set; }
        public string IconKey { get; set; }
        public bool IsEarned { get; set; }
        public DateTime? AwardedAt { get; set; }

        /// <summary>Mô tả điều kiện đạt huy hiệu (nạp bởi BadgeService).</summary>
        public string ConditionText { get; set; }

        /// <summary>Tiến độ hiện tại của người dùng so với điều kiện (VD: "3/5 bài").</summary>
        public string ProgressText { get; set; }

        // ===================== Hiển thị trên giao diện =====================

        /// <summary>Emoji tương ứng từng loại huy hiệu.</summary>
        public string Icon
        {
            get
            {
                switch (IconKey)
                {
                    case "first_step": return "🌱";
                    case "gold_score": return "🥇";
                    case "perfect": return "💎";
                    case "persistent": return "🔥";
                    case "master": return "👑";
                    default: return "🏅";
                }
            }
        }

        /// <summary>Màu nhận dạng của huy hiệu (viền thẻ, chữ trạng thái).</summary>
        public string AccentHex
        {
            get
            {
                switch (IconKey)
                {
                    case "gold_score": return "#FFD700";  // vàng - huy hiệu vàng điểm >= 8
                    case "perfect": return "#00F0FF";     // cyan - điểm tuyệt đối
                    case "persistent": return "#FF007F";  // hồng - kiên trì
                    case "master": return "#B388FF";      // tím - học bá
                    default: return "#00FF9C";            // xanh lá - bước đầu tiên
                }
            }
        }

        private SolidColorBrush _accentBrush;

        /// <summary>Brush viền thẻ đã dựng sẵn từ AccentHex (binding an toàn).</summary>
        public Brush AccentBrush
        {
            get
            {
                if (_accentBrush == null)
                {
                    _accentBrush = new SolidColorBrush(
                        (Color)ColorConverter.ConvertFromString(AccentHex));
                    _accentBrush.Freeze();
                }
                return _accentBrush;
            }
        }

        /// <summary>Trạng thái nhận được hay chưa, kèm ngày trao nếu có.</summary>
        public string EarnedText
        {
            get
            {
                if (!IsEarned) return "CHƯA NHẬN";
                return AwardedAt.HasValue
                    ? "ĐÃ NHẬN • " + AwardedAt.Value.ToString("dd/MM/yyyy")
                    : "ĐÃ NHẬN";
            }
        }
    }
}
