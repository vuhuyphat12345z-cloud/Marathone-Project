﻿using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using MarathoneUI.Data;
using MarathoneUI.Models;

namespace MarathoneUI.Services
{
    /// <summary>
    /// Dịch vụ dành cho tài khoản Admin.
    /// Bộ chức năng hoàn chỉnh:
    ///  + GetAllUsers / GetAllQuestions          : xem người dùng, ngân hàng câu hỏi.
    ///  + GetOptionsForQuestion                  : xem đáp án của một câu hỏi (dùng khi sửa).
    ///  + AddQuestion                            : THÊM câu hỏi mới kèm đáp án.
    ///  + UpdateQuestion                         : SỬA câu hỏi (nội dung + đáp án).
    ///  + DeleteQuestion                         : XÓA câu hỏi.
    ///  + GetStatistics                          : thống kê tổng quan (tài khoản, câu hỏi, bài thi...).
    ///  + GetTopicDistribution / GetTopStudents  : phân bố câu hỏi, top học viên.
    ///  + GetAllExamHistory                      : lịch sử thi của TẤT CẢ sinh viên.
    /// Mọi thao tác ghi đều dùng SqlTransaction để dữ liệu không bị lệch nửa chừng.
    /// </summary>
    public static class AdminService
    {
        /// <summary>Các mức nhận thức khớp CHECK constraint CHK_Questions_Bloom (tiếng Việt).</summary>
        public static readonly string[] BloomLevels = { "Nhớ", "Hiểu", "Vận dụng" };

        public static List<User> GetAllUsers()
        {
            var users = new List<User>();
            using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
            {
                conn.Open();
                string query = "SELECT UserId, Username, FullName, Class, Role, CreatedAt FROM Users ORDER BY UserId";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataReader r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            users.Add(new User
                            {
                                UserId = r.GetInt32(0),
                                Username = r.GetString(1),
                                FullName = r.GetString(2),
                                Class = r.IsDBNull(3) ? "N/A" : r.GetString(3),
                                Role = r.GetString(4),
                                CreatedAt = r.GetDateTime(5)
                            });
                        }
                    }
                }
            }
            return users;
        }

        public static List<Question> GetAllQuestions()
        {
            var questions = new List<Question>();
            using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
            {
                conn.Open();
                string query = "SELECT QuestionId, Content, Topic, BloomLevel, CreatedAt FROM Questions ORDER BY QuestionId";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataReader r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            questions.Add(new Question
                            {
                                QuestionId = r.GetInt32(0),
                                Content = r.GetString(1),
                                Topic = r.GetString(2),
                                BloomLevel = r.GetString(3),
                                CreatedAt = r.IsDBNull(4) ? DateTime.MinValue : r.GetDateTime(4)
                            });
                        }
                    }
                }
            }
            return questions;
        }

        /// <summary>Lấy danh sách đáp án của một câu hỏi (dùng khi mở cửa sổ SỬA).</summary>
        public static List<QuestionOption> GetOptionsForQuestion(int questionIds
        {
            var options = new List<QuestionOption>();
            using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
            {
                conn.Open();
                string query = @"SELECT OptionId, OptionText, IsCorrect
                                 FROM QuestionOptions
                                 WHERE QuestionId = @QId
                                 ORDER BY OptionId";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@QId", questionId);
                    using (SqlDataReader r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            options.Add(new QuestionOption
                            {
                                OptionId = r.GetInt32(0),
                                OptionText = r.GetString(1),
                                IsCorrect = r.GetBoolean(2)
                            });
                        }
                    }
                }
            }
            return options;
        }

        /// <summary>
        /// Kiểm tra dữ liệu câu hỏi trước khi lưu (dùng chung cho Add và Update).
        /// Trả về chuỗi lỗi tiếng Việt, rỗng nếu dữ liệu hợp lệ.
        /// </summary>
        private static string ValidateQuestionInput(string content, string topic, string bloomLevel,
                                                    List<QuestionOption> options)
        {
            if (string.IsNullOrWhiteSpace(content))
                return "Nội dung câu hỏi không được để trống!";
            if (string.IsNullOrWhiteSpace(topic))
                return "Chủ đề câu hỏi không được để trống!";
            if (topic.Trim().Length > 50)
                return "Chủ đề không được vượt quá 50 ký tự!";
            if (string.IsNullOrWhiteSpace(bloomLevel) ||
                Array.IndexOf(BloomLevels, bloomLevel) < 0)
                return "Vui lòng chọn đúng mức độ nhận thức: Nhớ, Hiểu hoặc Vận dụng!";
            if (options == null || options.Count < 2)
                return "Câu hỏi phải có ít nhất 2 đáp án!";
            foreach (var opt in options)
            {
                if (string.IsNullOrWhiteSpace(opt.OptionText))
                    return "Không được để trống nội dung đáp án!";
            }
            if (options.Count(o => o.IsCorrect) != 1)
                return "Câu hỏi phải có ĐÚNG MỘT đáp án đúng!";
            return "";
        }

        /// <summary>
        /// THÊM một câu hỏi mới cùng các đáp án. Trả về QuestionId mới,
        /// -1 nếu thất bại (kèm errorMsg bằng tiếng Việt).
        /// </summary>
        public static int AddQuestion(string content, string topic, string bloomLevel,
                                      List<QuestionOption> options, out string errorMsg)
        {
            errorMsg = ValidateQuestionInput(content, topic, bloomLevel, options);
            if (errorMsg.Length > 0) return -1;

            try
            {
                using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
                {
                    conn.Open();
                    using (SqlTransaction tran = conn.BeginTransaction())
                    {
                        try
                        {
                            int newId;
                            string insertQ = @"INSERT INTO Questions (Content, Topic, BloomLevel)
                                               OUTPUT INSERTED.QuestionId
                                               VALUES (@Content, @Topic, @Bloom)";
                            using (SqlCommand cmd = new SqlCommand(insertQ, conn, tran))
                            {
                                cmd.Parameters.AddWithValue("@Content", content.Trim());
                                cmd.Parameters.AddWithValue("@Topic", topic.Trim());
                                cmd.Parameters.AddWithValue("@Bloom", bloomLevel.Trim());
                                newId = (int)cmd.ExecuteScalar();
                            }

                            string insertO = @"INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect)
                                               VALUES (@QId, @Text, @Correct)";
                            foreach (var opt in options)
                            {
                                using (SqlCommand cmd = new SqlCommand(insertO, conn, tran))
                                {
                                    cmd.Parameters.AddWithValue("@QId", newId);
                                    cmd.Parameters.AddWithValue("@Text", opt.OptionText.Trim());
                                    cmd.Parameters.AddWithValue("@Correct", opt.IsCorrect);
                                    cmd.ExecuteNonQuery();
                                }
                            }

                            tran.Commit();
                            return newId;
                        }
                        catch (Exception inner)
                        {
                            tran.Rollback();
                            errorMsg = "Không thể thêm câu hỏi: " + inner.Message;
                            return -1;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                errorMsg = "Lỗi kết nối cơ sở dữ liệu: " + ex.Message;
                return -1;
            }
        }

        /// <summary>
        /// SỬA một câu hỏi: cập nhật nội dung/chủ đề/mức độ và thay toàn bộ đáp án.
        /// Trả về true nếu thành công.
        /// Lưu ý: FK ExamDetails.SelectedOptionId -> QuestionOptions có ON DELETE SET NULL
        /// nên khi xáo đáp án cũ, các dòng chi tiết bài thi cũ chỉ bị mất liên kết
        /// (SelectedOptionId về NULL) chứ không lỗi khóa ngoại.
        /// </summary>
        public static bool UpdateQuestion(int questionId, string content, string topic,
                                          string bloomLevel, List<QuestionOption> options,
                                          out string errorMsg)
        {
            errorMsg = ValidateQuestionInput(content, topic, bloomLevel, options);
            if (errorMsg.Length > 0) return false;

            try
            {
                using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
                {
                    conn.Open();
                    using (SqlTransaction tran = conn.BeginTransaction())
                    {
                        try
                        {
                            // (1) Cập nhật nội dung câu hỏi
                            string updateQ = @"UPDATE Questions
                                               SET Content = @Content, Topic = @Topic, BloomLevel = @Bloom
                                               WHERE QuestionId = @QId";
                            int affected;
                            using (SqlCommand cmd = new SqlCommand(updateQ, conn, tran))
                            {
                                cmd.Parameters.AddWithValue("@QId", questionId);
                                cmd.Parameters.AddWithValue("@Content", content.Trim());
                                cmd.Parameters.AddWithValue("@Topic", topic.Trim());
                                cmd.Parameters.AddWithValue("@Bloom", bloomLevel.Trim());
                                affected = cmd.ExecuteNonQuery();
                            }

                            if (affected == 0)
                            {
                                tran.Rollback();
                                errorMsg = "Không tìm thấy câu hỏi cần sửa (có thể đã bị xóa).";
                                return false;
                            }

                            // (2) Thay toàn bộ đáp án: xóa cũ -> thêm mới
                            using (SqlCommand cmd = new SqlCommand(
                                "DELETE FROM QuestionOptions WHERE QuestionId = @QId", conn, tran))
                            {
                                cmd.Parameters.AddWithValue("@QId", questionId);
                                cmd.ExecuteNonQuery();
                            }

                            string insertO = @"INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect)
                                               VALUES (@QId, @Text, @Correct)";
                            foreach (var opt in options)
                            {
                                using (SqlCommand cmd = new SqlCommand(insertO, conn, tran))
                                {
                                    cmd.Parameters.AddWithValue("@QId", questionId);
                                    cmd.Parameters.AddWithValue("@Text", opt.OptionText.Trim());
                                    cmd.Parameters.AddWithValue("@Correct", opt.IsCorrect);
                                    cmd.ExecuteNonQuery();
                                }
                            }

                            tran.Commit();
                            return true;
                        }
                        catch (Exception inner)
                        {
                            tran.Rollback();
                            errorMsg = "Không thể cập nhật câu hỏi: " + inner.Message;
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                errorMsg = "Lỗi kết nối cơ sở dữ liệu: " + ex.Message;
                return false;
            }
        }

        /// <summary>
        /// XÓA một câu hỏi. FK ExamDetails.QuestionId -> Questions KHÔNG cascade
        /// nên phải xóa các dòng chi tiết bài thi tham chiếu câu hỏi này TRƯỚC,
        /// nếu không SQL Server sẽ chặn xóa bằng lỗi khóa ngoại.
        /// </summary>
        public static bool DeleteQuestion(int questionId, out string errorMsg)
        {
            errorMsg = "";
            try
            {
                using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
                {
                    conn.Open();
                    using (SqlTransaction tran = conn.BeginTransaction())
                    {
                        try
                        {
                            // (1) Xóa chi tiết bài thi đã dùng câu hỏi này (bắt buộc làm trước)
                            using (SqlCommand cmd = new SqlCommand(
                                "DELETE FROM ExamDetails WHERE QuestionId = @QId", conn, tran))
                            {
                                cmd.Parameters.AddWithValue("@QId", questionId);
                                cmd.ExecuteNonQuery();
                            }

                            // (2) Xóa các đáp án của câu hỏi (khóa ngoại có CASCADE nhưng xóa tường minh cho rõ ràng)
                            using (SqlCommand cmd = new SqlCommand(
                                "DELETE FROM QuestionOptions WHERE QuestionId = @QId", conn, tran))
                            {
                                cmd.Parameters.AddWithValue("@QId", questionId);
                                cmd.ExecuteNonQuery();
                            }

                            // (3) Xóa chính câu hỏi
                            int affected;
                            using (SqlCommand cmd = new SqlCommand(
                                "DELETE FROM Questions WHERE QuestionId = @QId", conn, tran))
                            {
                                cmd.Parameters.AddWithValue("@QId", questionId);
                                affected = cmd.ExecuteNonQuery();
                            }

                            tran.Commit();

                            if (affected == 0)
                            {
                                errorMsg = "Không tìm thấy câu hỏi cần xóa (có thể đã bị xóa trước đó).";
                                return false;
                            }
                            return true;
                        }
                        catch (Exception inner)
                        {
                            tran.Rollback();
                            errorMsg = "Không thể xóa câu hỏi: " + inner.Message;
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                errorMsg = "Lỗi kết nối cơ sở dữ liệu: " + ex.Message;
                return false;
            }
        }

        /// <summary>Thống kê tổng quan cho tab THỐNG KÊ (các thẻ số liệu).</summary>
        public static StatisticsSummary GetStatistics()
        {
            var s = new StatisticsSummary();
            using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
            {
                conn.Open();
                string query = @"
                    SELECT
                        (SELECT COUNT(*) FROM Users)                          AS TongTaiKhoan,
                        (SELECT COUNT(*) FROM Users WHERE Role = 'Student')   AS TongHocVien,
                        (SELECT COUNT(*) FROM Questions)                      AS TongCauHoi,
                        (SELECT COUNT(*) FROM QuestionOptions)                AS TongDapAn,
                        (SELECT COUNT(*) FROM MarathonExams)                  AS TongPhienThi,
                        (SELECT COUNT(*) FROM MarathonExams WHERE IsCompleted = 1) AS PhienHoanThanh,
                        (SELECT ISNULL(ROUND(AVG(Score), 2), 0)
                         FROM MarathonExams WHERE IsCompleted = 1)            AS DiemTrungBinh,
                        (SELECT COUNT(*) FROM UserBadges)                     AS TongHuyHieu";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataReader r = cmd.ExecuteReader())
                    {
                        if (r.Read())
                        {
                            s.TotalAccounts = r.GetInt32(0);
                            s.TotalStudents = r.GetInt32(1);
                            s.TotalQuestions = r.GetInt32(2);
                            s.TotalOptions = r.GetInt32(3);
                            s.TotalExams = r.GetInt32(4);
                            s.CompletedExams = r.GetInt32(5);
                            s.AverageScore = Convert.ToDouble(r.GetValue(6));
                            s.TotalBadgesAwarded = r.GetInt32(7);
                        }
                    }
                }
            }
            return s;
        }

        /// <summary>Phân bố số câu hỏi theo chủ đề (vẽ bảng thống kê).</summary>
        public static List<TopicDistributionItem> GetTopicDistribution()
        {
            var list = new List<TopicDistributionItem>();
            using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
            {
                conn.Open();
                string query = @"SELECT Topic, COUNT(*) AS SoCauHoi
                                 FROM Questions
                                 GROUP BY Topic
                                 ORDER BY SoCauHoi DESC, Topic";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataReader r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            list.Add(new TopicDistributionItem
                            {
                                Topic = r.GetString(0),
                                QuestionCount = r.GetInt32(1)
                            });
                        }
                    }
                }
            }
            return list;
        }

        /// <summary>Top 10 sinh viên có điểm trung bình cao nhất (chỉ bài đã nộp).</summary>
        public static List<TopStudentItem> GetTopStudents()
        {
            var list = new List<TopStudentItem>();
            using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
            {
                conn.Open();
                string query = @"SELECT TOP 10
                                     u.FullName,
                                     ISNULL(u.Class, N'N/A') AS Lop,
                                     COUNT(e.ExamId)          AS SoBaiThi,
                                     MAX(e.Score)             AS DiemCaoNhat,
                                     ROUND(AVG(e.Score), 2)   AS DiemTrungBinh
                                 FROM Users u
                                 JOIN MarathonExams e ON e.UserId = u.UserId
                                 WHERE e.IsCompleted = 1
                                 GROUP BY u.UserId, u.FullName, u.Class
                                 ORDER BY DiemTrungBinh DESC, SoBaiThi DESC";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataReader r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            list.Add(new TopStudentItem
                            {
                                FullName = r.GetString(0),
                                ClassName = r.GetString(1),
                                ExamCount = r.GetInt32(2),
                                BestScore = Convert.ToDouble(r.GetValue(3)),
                                AverageScore = Convert.ToDouble(r.GetValue(4))
                            });
                        }
                    }
                }
            }
            return list;
        }

        /// <summary>
        /// Lịch sử thi của TẤT CẢ sinh viên (Admin xem toàn hệ thống),
        /// JOIN bảng Users để hiển thị ai làm bài thi nào.
        /// </summary>
        public static List<AllExamHistoryItem> GetAllExamHistory()
        {
            var list = new List<AllExamHistoryItem>();
            using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
            {
                conn.Open();
                string query = @"SELECT TOP 200
                                     e.ExamId,
                                     u.Username,
                                     u.FullName,
                                     ISNULL(u.Class, N'N/A') AS Lop,
                                     e.StartTime,
                                     e.TotalQuestions,
                                     e.CorrectAnswers,
                                     e.Score,
                                     e.IsCompleted
                                 FROM MarathonExams e
                                 JOIN Users u ON u.UserId = e.UserId
                                 ORDER BY e.StartTime DESC";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataReader r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            list.Add(new AllExamHistoryItem
                            {
                                ExamId = r.GetInt32(0),
                                Username = r.GetString(1),
                                FullName = r.GetString(2),
                                ClassName = r.GetString(3),
                                StartTime = r.GetDateTime(4),
                                TotalQuestions = r.GetInt32(5),
                                CorrectAnswers = r.GetInt32(6),
                                Score = Convert.ToDouble(r.GetValue(7)),
                                IsCompleted = r.GetBoolean(8)
                            });
                        }
                    }
                }
            }
            return list;
        }
    }
}
