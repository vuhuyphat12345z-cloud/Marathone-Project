﻿using System;
using Microsoft.Data.SqlClient;
using MarathoneUI.Data;
using MarathoneUI.Models;

namespace MarathoneUI.Services
{
    public static class AuthService
    {
        public static bool TestConnection(out string message)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
                {
                    conn.Open();
                    message = "Kết nối tới Database [DoAnDotNet] thành công!";
                    return true;
                }
            }
            catch (Exception ex)
            {
                message = $"Không thể kết nối CSDL: {ex.Message}";
                return false;
            }
        }

        public static bool Login(string username, string password, out User user)
        {
            user = null;
            try
            {
                using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
                {
                    conn.Open();
                    string query = "SELECT UserId, Username, FullName, Class, Role FROM Users WHERE Username = @User AND PasswordHash = @Pass";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@User", username);
                        cmd.Parameters.AddWithValue("@Pass", password);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                user = new User
                                {
                                    UserId = reader.GetInt32(0),
                                    Username = reader.GetString(1),
                                    FullName = reader.GetString(2),
                                    Class = reader.IsDBNull(3) ? "N/A" : reader.GetString(3),
                                    Role = reader.GetString(4)
                                };
                                return true;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Lỗi hệ thống đăng nhập: {ex.Message}");
            }
            return false;
        }

        public static int Register(string username, string password, string fullName, string className, out string errorMsg)
        {
            errorMsg = "";
            try
            {
                using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand("sp_RegisterUser", conn))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Username", username);
                        cmd.Parameters.AddWithValue("@PasswordHash", password);
                        cmd.Parameters.AddWithValue("@FullName", fullName);
                        cmd.Parameters.AddWithValue("@Class", string.IsNullOrEmpty(className) ? (object)DBNull.Value : className);
                        cmd.Parameters.AddWithValue("@Role", "Student");

                        object result = cmd.ExecuteScalar();
                        return result != null ? Convert.ToInt32(result) : -1;
                    }
                }
            }
            catch (Exception ex)
            {
                errorMsg = ex.Message;
                return -1;
            }
        }
    }
}