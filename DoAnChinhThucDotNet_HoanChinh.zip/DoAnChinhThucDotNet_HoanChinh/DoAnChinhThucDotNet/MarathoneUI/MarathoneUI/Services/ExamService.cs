﻿using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using MarathoneUI.Data;
using MarathoneUI.Models;

namespace MarathoneUI.Services
{
    public class ExamService
    {
        private readonly int _userId;

        public ExamService(int userId)
        {
            _userId = userId;
        }

        public List<Question> GetRandomQuestions(int count = 50)
        {
            var list = new List<Question>();
            using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
            {
                conn.Open();
                string query = $"SELECT TOP {count} QuestionId, Content, Topic, BloomLevel FROM Questions ORDER BY NEWID()";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataReader r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            list.Add(new Question
                            {
                                QuestionId = r.GetInt32(0),
                                Content = r.GetString(1),
                                Topic = r.GetString(2),
                                BloomLevel = r.GetString(3)
                            });
                        }
                    }
                }
            }
            return list;
        }

        public List<QuestionOption> GetOptionsForQuestion(int questionId)
        {
            var options = new List<QuestionOption>();
            using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
            {
                conn.Open();
                string query = "SELECT OptionId, OptionText, IsCorrect FROM QuestionOptions WHERE QuestionId = @QId";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@QId", questionId);
                    using (SqlDataReader r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            options.Add(new QuestionOption
                            {
                                OptionId = r.GetInt32(0),
                                OptionText = r.GetString(1),
                                IsCorrect = r.GetBoolean(2)
                            });
                        }
                    }
                }
            }
            return options;
        }

        public int CreateNewExamSession(int totalQuestions)
        {
            using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
            {
                conn.Open();
                string query = "INSERT INTO MarathonExams (UserId, TotalQuestions, IsCompleted) OUTPUT INSERTED.ExamId VALUES (@UserId, @TotalQ, 0);";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserId", _userId);
                    cmd.Parameters.AddWithValue("@TotalQ", totalQuestions);
                    return (int)cmd.ExecuteScalar();
                }
            }
        }

        /// <summary>
        /// Lưu chi tiết một câu trả lời. Đã nâng cấp thành UPSERT: nếu người thi
        /// đổi đáp án cho cùng một câu hỏi trong phiên thi thì bản ghi cũ sẽ được
        /// xóa và ghi lại, tránh trùng (ExamId, QuestionId) của UNIQUE constraint.
        /// </summary>
        public void SaveExamDetail(int examId, int questionId, int? selectedOptionId, bool isCorrect, string bloomLevel)
        {
            using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
            {
                conn.Open();

                // (1) Xóa đáp án cũ của câu hỏi này trong cùng phiên thi (nếu có)
                string delete = "DELETE FROM ExamDetails WHERE ExamId = @ExamId AND QuestionId = @QId";
                using (SqlCommand cmd = new SqlCommand(delete, conn))
                {
                    cmd.Parameters.AddWithValue("@ExamId", examId);
                    cmd.Parameters.AddWithValue("@QId", questionId);
                    cmd.ExecuteNonQuery();
                }

                // (2) Ghi đáp án mới
                string insert = @"INSERT INTO ExamDetails (ExamId, QuestionId, SelectedOptionId, IsCorrect, BloomLevel)
                                  VALUES (@ExamId, @QId, @OptId, @IsCorrect, @Bloom)";
                using (SqlCommand cmd = new SqlCommand(insert, conn))
                {
                    cmd.Parameters.AddWithValue("@ExamId", examId);
                    cmd.Parameters.AddWithValue("@QId", questionId);
                    cmd.Parameters.AddWithValue("@OptId", (object)selectedOptionId ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@IsCorrect", isCorrect);
                    cmd.Parameters.AddWithValue("@Bloom", (object)bloomLevel ?? DBNull.Value);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        /// <summary>
        /// NỘP BÀI: gọi thủ tục sp_SubmitExam có sẵn trong CSDL (DoAnDotNet).
        /// SP tự đếm số câu đúng từ bảng ExamDetails, tính điểm thang 10,
        /// cập nhật MarathonExams (EndTime, CorrectAnswers, Score, IsCompleted)
        /// và trả về result set: ExamId, TotalQuestions, CorrectAnswers, Score.
        /// </summary>
        public (int TotalQuestions, int CorrectAnswers, double Score) SubmitExam(int examId)
        {
            using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("sp_SubmitExam", conn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ExamId", examId);

                    using (SqlDataReader r = cmd.ExecuteReader())
                    {
                        if (r.Read())
                        {
                            int total = r.GetInt32(1);
                            int correct = r.GetInt32(2);
                            double score = Convert.ToDouble(r.GetValue(3));
                            return (total, correct, score);
                        }
                    }
                }
            }
            // Không đọc được kết quả trả về -> dữ liệu an toàn nhưng báo số 0
            return (0, 0, 0.0);
        }

        /// <summary>
        /// Lấy lịch sử thi của user. Đã sửa lỗi crash: kiểm tra IsDBNull trước khi
        /// đọc Score (bài chưa nộp), đồng thời đọc thêm cột CorrectAnswers của CSDL mới.
        /// </summary>
        public List<ExamHistoryItem> GetExamHistory()
        {
            var history = new List<ExamHistoryItem>();
            using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
            {
                conn.Open();
                string query = @"SELECT ExamId, StartTime, TotalQuestions, CorrectAnswers, Score, IsCompleted
                                 FROM MarathonExams
                                 WHERE UserId = @UserId
                                 ORDER BY StartTime DESC";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserId", _userId);
                    using (SqlDataReader r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            history.Add(new ExamHistoryItem
                            {
                                ExamId = r.GetInt32(0),
                                StartTime = r.GetDateTime(1),
                                TotalQuestions = r.GetInt32(2),
                                CorrectAnswers = r.IsDBNull(3) ? 0 : r.GetInt32(3),
                                Score = r.IsDBNull(4) ? 0.0 : Convert.ToDouble(r.GetValue(4)),
                                IsCompleted = r.GetBoolean(5)
                            });
                        }
                    }
                }
            }
            return history;
        }

        /// <summary>Đọc thông tin cơ bản của một phiên thi (thời gian + điểm) cho header cửa sổ chi tiết.</summary>
        public static (DateTime start, double score) GetExamMeta(int examId)
        {
            using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
            {
                conn.Open();
                string query = "SELECT StartTime, Score FROM MarathonExams WHERE ExamId = @ExamId";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@ExamId", examId);
                    using (SqlDataReader r = cmd.ExecuteReader())
                    {
                        if (r.Read())
                        {
                            DateTime start = r.GetDateTime(0);
                            double score = r.IsDBNull(1) ? 0.0 : Convert.ToDouble(r.GetValue(1));
                            return (start, score);
                        }
                    }
                }
            }
            throw new Exception("Không tìm thấy bài thi có mã " + examId);
        }

        /// <summary>
        /// Lấy chi tiết từng câu hỏi của một bài thi (dùng cho cửa sổ XEM CHI TIẾT).
        /// Nếu userIdFilter khác null thì chỉ trả kết quả khi bài thi thuộc về
        /// đúng user đó (sinh viên chỉ được xem bài của mình; Admin truyền null).
        /// </summary>
        public static List<ExamReviewItem> GetExamDetails(int examId, int? userIdFilter)
        {
            var items = new List<ExamReviewItem>();
            using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
            {
                conn.Open();

                // Kiểm tra quyền: sinh viên chỉ xem được bài thi của chính mình
                if (userIdFilter.HasValue)
                {
                    string ownerCheck = "SELECT UserId FROM MarathonExams WHERE ExamId = @ExamId";
                    using (SqlCommand cmd = new SqlCommand(ownerCheck, conn))
                    {
                        cmd.Parameters.AddWithValue("@ExamId", examId);
                        object owner = cmd.ExecuteScalar();
                        if (owner == null || Convert.ToInt32(owner) != userIdFilter.Value)
                        {
                            throw new UnauthorizedAccessException(
                                "Bạn không có quyền xem chi tiết bài thi này!");
                        }
                    }
                }

                // Đáp án đã chọn (LEFT JOIN - có thể bỏ trống) và đáp án đúng (JOIN)
                string query = @"
                    SELECT
                        q.QuestionId,
                        q.Content,
                        q.Topic,
                        q.BloomLevel,
                        sel.OptionText  AS SelectedText,
                        corr.OptionText AS CorrectText,
                        d.IsCorrect
                    FROM ExamDetails d
                    JOIN Questions q
                        ON q.QuestionId = d.QuestionId
                    JOIN QuestionOptions corr
                        ON corr.QuestionId = d.QuestionId AND corr.IsCorrect = 1
                    LEFT JOIN QuestionOptions sel
                        ON sel.OptionId = d.SelectedOptionId
                    WHERE d.ExamId = @ExamId
                    ORDER BY q.QuestionId";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@ExamId", examId);
                    using (SqlDataReader r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            items.Add(new ExamReviewItem
                            {
                                QuestionId = r.GetInt32(0),
                                QuestionContent = r.GetString(1),
                                Topic = r.GetString(2),
                                BloomLevel = r.GetString(3),
                                SelectedAnswer = r.IsDBNull(4) ? null : r.GetString(4),
                                CorrectAnswer = r.GetString(5),
                                IsCorrect = r.GetBoolean(6)
                            });
                        }
                    }
                }
            }
            return items;
        }
    }
}
