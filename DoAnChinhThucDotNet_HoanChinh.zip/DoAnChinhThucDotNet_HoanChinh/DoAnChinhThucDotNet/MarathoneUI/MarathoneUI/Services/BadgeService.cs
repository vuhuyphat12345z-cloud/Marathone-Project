﻿using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using MarathoneUI.Data;
using MarathoneUI.Models;

namespace MarathoneUI.Services
{
    /// <summary>
    /// Xử lý nghiệp vụ HUY HIỆU thành tựu của sinh viên (bảng Badges/UserBadges).
    ///  + GetUserBadges    : danh mục huy hiệu + trạng thái đạt/chưa đạt + tiến độ.
    ///  + EvaluateAndAward : gọi sp_AwardBadges sau khi nộp bài để tự động trao
    ///                       huy hiệu (điểm >= 8 -> HUY HIỆU VÀNG, 10 điểm -> hoàn
    ///                       hảo, 5 bài -> kiên trì, TB >= 8 -> học bá...) và
    ///                       trả về danh sách huy hiệu MỚI nhận để chúc mừng.
    ///  + CountEarned      : đếm nhanh số huy hiệu đã nhận (hiển thị tổng quan).
    /// Điều kiện trao nằm trong sp_AwardBadges của CSDL — phần này chỉ đọc.
    /// </summary>
    public class BadgeService
    {
        private readonly int _userId;

        public BadgeService(int userId)
        {
            _userId = userId;
        }

        /// <summary>
        /// Lấy toàn bộ danh mục huy hiệu kèm trạng thái của người dùng hiện tại
        /// và tiến độ so với điều kiện (để hiện gợi ý trên thẻ chưa nhận).
        /// </summary>
        public List<BadgeItem> GetUserBadges()
        {
            var badges = new List<BadgeItem>();

            // Thống kê phục vụ tính tiến độ: số bài đã nộp, điểm cao nhất, điểm TB
            int completed = 0;
            double best = 0, avg = 0;
            using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(@"
                        SELECT COUNT(*), ISNULL(MAX(Score), 0), ISNULL(AVG(Score), 0)
                        FROM MarathonExams WHERE UserId = @Uid AND IsCompleted = 1", conn))
                {
                    cmd.Parameters.AddWithValue("@Uid", _userId);
                    using (SqlDataReader r = cmd.ExecuteReader())
                    {
                        if (r.Read())
                        {
                            completed = r.GetInt32(0);
                            best = Convert.ToDouble(r.GetValue(1));
                            avg = Convert.ToDouble(r.GetValue(2));
                        }
                    }
                }

                // Danh mục huy hiệu + ngày trao (nếu có) của user này
                using (SqlCommand cmd = new SqlCommand(@"
                        SELECT b.BadgeId, b.BadgeName, b.Description, b.IconUrl, ub.AwardedAt
                        FROM Badges b
                        LEFT JOIN UserBadges ub
                            ON ub.BadgeId = b.BadgeId AND ub.UserId = @Uid
                        ORDER BY b.BadgeId", conn))
                {
                    cmd.Parameters.AddWithValue("@Uid", _userId);
                    using (SqlDataReader r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            badges.Add(new BadgeItem
                            {
                                BadgeId = r.GetInt32(0),
                                BadgeName = r.GetString(1),
                                Description = r.IsDBNull(2) ? "" : r.GetString(2),
                                IconKey = r.IsDBNull(3) ? "" : r.GetString(3),
                                IsEarned = !r.IsDBNull(4),
                                AwardedAt = r.IsDBNull(4) ? (DateTime?)null : r.GetDateTime(4)
                            });
                        }
                    }
                }
            }

            // Điền mô tả điều kiện + tiến độ hiện tại cho từng thẻ huy hiệu
            foreach (var b in badges)
            {
                switch (b.IconKey)
                {
                    case "first_step":
                        b.ConditionText = "Hoàn thành 1 bài thi (điểm bất kỳ)";
                        b.ProgressText = b.IsEarned ? "" : $"{completed}/1 bài thi";
                        break;
                    case "gold_score":
                        b.ConditionText = "Đạt từ 8.0 điểm trở lên trong một bài thi";
                        b.ProgressText = b.IsEarned ? "" : $"Điểm cao nhất hiện tại: {best:0.0}";
                        break;
                    case "perfect":
                        b.ConditionText = "Đạt điểm tuyệt đối 10/10 trong một bài thi";
                        b.ProgressText = b.IsEarned ? "" : $"Điểm cao nhất hiện tại: {best:0.0}";
                        break;
                    case "persistent":
                        b.ConditionText = "Hoàn thành 5 bài thi Marathon";
                        b.ProgressText = b.IsEarned ? "" : $"{completed}/5 bài thi";
                        break;
                    case "master":
                        b.ConditionText = "Điểm trung bình từ 8.0 trở lên sau ít nhất 3 bài thi";
                        b.ProgressText = b.IsEarned ? "" : $"Điểm TB: {avg:0.00} ({completed} bài)";
                        break;
                    default:
                        b.ConditionText = b.Description;
                        b.ProgressText = "";
                        break;
                }
            }

            return badges;
        }

        /// <summary>
        /// Gọi sp_AwardBadges của CSDL để tự động trao huy hiệu sau khi nộp bài.
        /// Trả về danh sách huy hiệu MỚI được trao (rỗng = không có huy hiệu mới).
        /// </summary>
        public static List<BadgeItem> EvaluateAndAward(int userId, int examId)
        {
            var newBadges = new List<BadgeItem>();
            using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("sp_AwardBadges", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@UserId", userId);
                    cmd.Parameters.AddWithValue("@ExamId", examId);

                    using (SqlDataReader r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            newBadges.Add(new BadgeItem
                            {
                                BadgeId = r.GetInt32(0),
                                BadgeName = r.GetString(1),
                                Description = r.IsDBNull(2) ? "" : r.GetString(2),
                                IconKey = r.IsDBNull(3) ? "" : r.GetString(3),
                                IsEarned = true,
                                AwardedAt = r.IsDBNull(4) ? (DateTime?)null : r.GetDateTime(4)
                            });
                        }
                    }
                }
            }
            return newBadges;
        }

        /// <summary>Đếm số huy hiệu người dùng đã nhận (hiển thị tổng quan nhanh).</summary>
        public static int CountEarned(int userId)
        {
            using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(
                    "SELECT COUNT(*) FROM UserBadges WHERE UserId = @Uid", conn))
                {
                    cmd.Parameters.AddWithValue("@Uid", userId);
                    return (int)cmd.ExecuteScalar();
                }
            }
        }

        /// <summary>Tổng số huy hiệu trong danh mục (để hiện dạng X/Y).</summary>
        public static int CountTotal()
        {
            using (SqlConnection conn = new SqlConnection(DatabaseHelper.ConnectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Badges", conn))
                {
                    return (int)cmd.ExecuteScalar();
                }
            }
        }
    }
}
