﻿using System;
using System.Windows;
using MarathoneUI.Services;
using MarathoneUI.ViewModels.Xuly;

namespace MarathoneUI.Views
{
    /// <summary>
    /// Cửa sổ XEM CHI TIẾT BÀI THI: hiển thị từng câu hỏi, đáp án đã chọn,
    /// đáp án đúng và kết quả ĐÚNG/SAI của một bài thi đã nộp.
    ///  + Sinh viên mở từ Lịch sử thi  : chỉ xem được bài của mình.
    ///  + Admin mở từ tab Thống kê     : xem được bài thi của bất kỳ ai.
    /// </summary>
    public partial class ExamReviewWindow : Window
    {
        /// <param name="examId">Mã bài thi cần xem.</param>
        /// <param name="userIdFilter">Mã sinh viên (giới hạn quyền), null nếu Admin.</param>
        public ExamReviewWindow(int examId, int? userIdFilter)
        {
            InitializeComponent();

            // Lấy thông tin phiên thi (điểm, thời gian) để hiển thị header
            DateTime startTime = DateTime.MinValue;
            double score = 0;
            try
            {
                var (start, sc) = ExamService.GetExamMeta(examId);
                startTime = start;
                score = sc;
            }
            catch
            {
                // Không đọc được meta vẫn cho mở cửa sổ (header để giá trị mặc định)
            }

            try
            {
                DataContext = new ExamReviewViewModel(examId, userIdFilter, startTime, score);
            }
            catch (UnauthorizedAccessException)
            {
                MessageBox.Show("Bạn không có quyền xem chi tiết bài thi này!",
                    "Không có quyền truy cập", MessageBoxButton.OK, MessageBoxImage.Warning);
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                    "Lỗi tải chi tiết", MessageBoxButton.OK, MessageBoxImage.Error);
                Close();
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
