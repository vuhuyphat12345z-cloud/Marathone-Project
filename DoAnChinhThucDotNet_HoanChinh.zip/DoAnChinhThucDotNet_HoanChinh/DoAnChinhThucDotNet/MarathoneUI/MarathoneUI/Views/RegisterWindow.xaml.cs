﻿using System.Windows;
using System.Windows.Controls;
using MarathoneUI.ViewModels.Xuly;

namespace MarathoneUI.Views
{
    /// <summary>
    /// Interaction logic for RegisterWindow.xaml
    /// Man hinh dang ky tai khoan moi (file moi). PasswordBox khong cho binding
    /// truc tiep property Password vi ly do bao mat, nen dong bo qua code-behind.
    /// </summary>
    public partial class RegisterWindow : Window
    {
        public RegisterWindow()
        {
            InitializeComponent();

            // Dong bo mat khau tu PasswordBox sang ViewModel
            PassBox.PasswordChanged += (s, e) =>
            {
                if (DataContext is RegisterViewModel vm)
                {
                    vm.Password = PassBox.Password;
                }
            };

            ConfirmPassBox.PasswordChanged += (s, e) =>
            {
                if (DataContext is RegisterViewModel vm)
                {
                    vm.ConfirmPassword = ConfirmPassBox.Password;
                }
            };
        }
    }
}
