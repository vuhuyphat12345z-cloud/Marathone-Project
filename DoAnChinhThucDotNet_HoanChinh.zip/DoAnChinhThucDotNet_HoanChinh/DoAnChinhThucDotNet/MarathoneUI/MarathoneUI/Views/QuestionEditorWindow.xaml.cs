﻿using System.Windows;
using MarathoneUI.Models;
using MarathoneUI.ViewModels.Xuly;

namespace MarathoneUI.Views
{
    /// <summary>
    /// Cửa sổ soạn câu hỏi cho Admin, dùng cho cả 2 chế độ:
    ///  + new QuestionEditorWindow()               -> THÊM câu hỏi mới.
    ///  + new QuestionEditorWindow(question)       -> SỬA câu hỏi đã chọn.
    /// Kết quả: DialogResult = true nếu đã lưu thành công trong CSDL.
    /// </summary>
    public partial class QuestionEditorWindow : Window
    {
        public QuestionEditorWindow()
        {
            InitializeComponent();
        }

        /// <summary>Mở cửa sổ ở chế độ SỬA với câu hỏi hiện có.</summary>
        public QuestionEditorWindow(Question existing) : this()
        {
            DataContext = new QuestionEditorViewModel(existing);
        }
    }
}
