﻿using System.Windows.Controls;

namespace MarathoneUI.Views
{
    /// <summary>
    /// Màn hình HUY HIỆU THÀNH TỰU — DataContext được MainViewModel gắn
    /// BadgeViewModel khi điều hướng (BadgeView { DataContext = ... }).
    /// </summary>
    public partial class BadgeView : UserControl
    {
        public BadgeView()
        {
            InitializeComponent();
        }
    }
}
