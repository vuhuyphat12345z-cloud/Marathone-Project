﻿using System.Collections.Generic;
using System.Windows;
using MarathoneUI.Models;
using MarathoneUI.ViewModels.Xuly;

namespace MarathoneUI.Views
{
    /// <summary>
    /// Cửa sổ chúc mừng sinh viên vừa nhận huy hiệu mới sau khi nộp bài.
    /// Nhận danh sách huy hiệu (từ sp_AwardBadges) qua constructor.
    /// </summary>
    public partial class BadgeEarnedWindow : Window
    {
        public BadgeEarnedWindow(List<BadgeItem> newBadges)
        {
            InitializeComponent();
            DataContext = new BadgeEarnedViewModel(newBadges);
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
