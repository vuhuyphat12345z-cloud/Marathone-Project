﻿using System;
using System.Windows;
using System.Windows.Input;
using MarathoneUI.Services;
using MarathoneUI.ViewModels.Support;

namespace MarathoneUI.ViewModels.Xuly
{
    /// <summary>
    /// ViewModel cho man hinh dang ky tai khoan moi.
    /// File moi: AuthService.Register() va thu tuc sp_RegisterUser ben CSDL da co
    /// san nhung du an WPF khong co man hinh dang ky nao goi den chung.
    /// </summary>
    public class RegisterViewModel : BaseViewModel
    {
        private string _username;
        private string _password;
        private string _confirmPassword;
        private string _fullName;
        private string _className;
        private string _errorMessage;

        public string Username
        {
            get => _username;
            set { _username = value; OnPropertyChanged(); }
        }

        public string Password
        {
            get => _password;
            set { _password = value; OnPropertyChanged(); }
        }

        public string ConfirmPassword
        {
            get => _confirmPassword;
            set { _confirmPassword = value; OnPropertyChanged(); }
        }

        public string FullName
        {
            get => _fullName;
            set { _fullName = value; OnPropertyChanged(); }
        }

        public string ClassName
        {
            get => _className;
            set { _className = value; OnPropertyChanged(); }
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            set { _errorMessage = value; OnPropertyChanged(); }
        }

        public ICommand RegisterCommand { get; }
        public ICommand CancelCommand { get; }

        public RegisterViewModel()
        {
            RegisterCommand = new RelayCommand(ExecuteRegister);
            CancelCommand = new RelayCommand(ExecuteCancel);
        }

        private void ExecuteRegister(object parameter)
        {
            ErrorMessage = string.Empty;

            // 1. Kiem tra du lieu dau vao
            if (string.IsNullOrWhiteSpace(Username) ||
                string.IsNullOrWhiteSpace(Password) ||
                string.IsNullOrWhiteSpace(FullName))
            {
                ErrorMessage = "Vui lòng nhập đầy đủ Tên đăng nhập, Mật khẩu và Họ tên!";
                return;
            }

            if (Username.Trim().Length < 3)
            {
                ErrorMessage = "Tên đăng nhập phải có ít nhất 3 ký tự!";
                return;
            }

            if (Password.Length < 4)
            {
                ErrorMessage = "Mật khẩu phải có ít nhất 4 ký tự!";
                return;
            }

            if (!string.Equals(Password, ConfirmPassword, StringComparison.Ordinal))
            {
                ErrorMessage = "Mật khẩu nhập lại không khớp!";
                return;
            }

            // 2. Goi AuthService.Register (thu tuc sp_RegisterUser trong CSDL)
            int newId = AuthService.Register(
                Username.Trim(), Password, FullName.Trim(),
                string.IsNullOrWhiteSpace(ClassName) ? null : ClassName.Trim(),
                out string errorMsg);

            if (newId == -1)
            {
                ErrorMessage = string.IsNullOrEmpty(errorMsg)
                    ? "Đăng ký thất bại! Tên đăng nhập có thể đã tồn tại."
                    : errorMsg;
                return;
            }

            // 3. Thanh cong -> thong bao va dong cua so dang ky
            MessageBox.Show(
                $"Đăng ký tài khoản thành công!\nMã thành viên của bạn là: {newId}\n" +
                "Bạn có thể quay lại màn hình đăng nhập.",
                "Đăng ký thành công", MessageBoxButton.OK, MessageBoxImage.Information);

            if (parameter is Window window)
            {
                window.Close();
            }
        }

        private void ExecuteCancel(object parameter)
        {
            if (parameter is Window window)
            {
                window.Close();
            }
        }
    }
}
