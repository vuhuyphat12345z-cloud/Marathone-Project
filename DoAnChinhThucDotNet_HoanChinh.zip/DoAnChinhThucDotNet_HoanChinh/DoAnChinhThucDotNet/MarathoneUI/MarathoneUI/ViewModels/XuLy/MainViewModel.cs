﻿using System;
using System.Windows;
using System.Windows.Input;
using MarathoneUI.Models;
using MarathoneUI.Views;
using MarathoneUI.ViewModels.Support;

namespace MarathoneUI.ViewModels.Xuly
{
    /// <summary>
    /// ViewModel trung tam cua cua so chinh (MainWindow).
    /// File moi: truoc day MainWindow bind CurrentView, NavigateExamCommand,
    /// NavigateResultCommand, NavigateAdminCommand, LogoutCommand nhung khong ton
    /// tai ViewModel nao cung cap cac property/command nay -> nut bam chet, man
    /// hinh trang. Lop nay hoan thien bo dieu huong theo vai tro (role).
    /// </summary>
    public class MainViewModel : BaseViewModel
    {
        private readonly User _user;
        private readonly Window _ownerWindow;
        private ExamViewModel _examVm;
        private object _currentView;

        /// <summary>View hien tai hien thi trong ContentControl cua MainWindow.</summary>
        public object CurrentView
        {
            get => _currentView;
            set { _currentView = value; OnPropertyChanged(); }
        }

        /// <summary>Chào mừng trên sidebar (vai trò hiển thị bằng tiếng Việt).</summary>
        public string WelcomeText => $"{_user.FullName} ({RoleDisplayText})";

        /// <summary>Chuyển vai trò trong CSDL sang tiếng Việt để hiển thị.</summary>
        public string RoleDisplayText =>
            string.Equals(_user.Role, "Admin", StringComparison.OrdinalIgnoreCase)
                ? "Quản trị viên"
                : "Sinh viên";

        /// <summary>Chi hien nut ADMIN PANEL khi dang nhap bang tai khoan Admin.</summary>
        public Visibility AdminVisibility =>
            string.Equals(_user.Role, "Admin", StringComparison.OrdinalIgnoreCase)
                ? Visibility.Visible
                : Visibility.Collapsed;

        public ICommand NavigateExamCommand { get; }
        public ICommand NavigateResultCommand { get; }
        public ICommand NavigateBadgeCommand { get; }
        public ICommand NavigateAdminCommand { get; }
        public ICommand LogoutCommand { get; }

        public MainViewModel(User user, Window ownerWindow)
        {
            _user = user ?? throw new ArgumentNullException(nameof(user));
            _ownerWindow = ownerWindow ?? throw new ArgumentNullException(nameof(ownerWindow));

            NavigateExamCommand = new RelayCommand(_ => NavigateToExam());
            NavigateResultCommand = new RelayCommand(_ => NavigateToResults());
            NavigateBadgeCommand = new RelayCommand(_ => NavigateToBadge());
            NavigateAdminCommand = new RelayCommand(
                _ => NavigateToAdmin(),
                _ => string.Equals(_user.Role, "Admin", StringComparison.OrdinalIgnoreCase));
            LogoutCommand = new RelayCommand(_ => ExecuteLogout());

            // Man hinh mac dinh: lich su thi (an toan, khong tao phien thi moi).
            NavigateToResults();
        }

        private void NavigateToExam()
        {
            // Dang co bai thi CHUA nop -> hoi xac nhan truoc khi tao bai thi moi
            if (_examVm != null && !_examVm.IsSubmitted)
            {
                var confirm = MessageBox.Show(
                    "Bạn đang có bài thi chưa nộp!\n" +
                    "Bắt đầu bài thi MỚI sẽ bỏ bài thi đang làm dở.\n\n" +
                    "Bạn có muốn tiếp tục không?",
                    "Bài thi đang thực hiện", MessageBoxButton.YesNo,
                    MessageBoxImage.Question, MessageBoxResult.No);
                if (confirm != MessageBoxResult.Yes) return;
            }

            // Dừng đồng hồ bài cũ để tránh tự động nộp bài trong nền
            _examVm?.Abandon();

            _examVm = new ExamViewModel(_user.UserId);
            _examVm.ExamFinished += OnExamFinished;
            CurrentView = new ExamView { DataContext = _examVm };
        }

        private void OnExamFinished()
        {
            // Sau khi nop bai -> chuyen sang man hinh lich su/ket qua
            NavigateToResults();
        }

        private void NavigateToResults()
        {
            _examVm?.Abandon();
            _examVm = null;
            CurrentView = new ResultView { DataContext = new ResultViewModel(_user.UserId) };
        }

        private void NavigateToBadge()
        {
            // Man hinh huy hieu chi doc, khong anh huong bai thi dang lam
            _examVm?.Abandon();
            _examVm = null;
            CurrentView = new BadgeView { DataContext = new BadgeViewModel(_user.UserId) };
        }

        private void NavigateToAdmin()
        {
            if (!string.Equals(_user.Role, "Admin", StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show("Chức năng này chỉ dành cho tài khoản Admin!",
                    "Không có quyền truy cập", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            _examVm?.Abandon();
            _examVm = null;
            CurrentView = new AdminView { DataContext = new AdminViewModel() };
        }

        private void ExecuteLogout()
        {
            var confirm = MessageBox.Show(
                $"Bạn có chắc muốn đăng xuất khỏi tài khoản {_user.Username} không?",
                "Đăng xuất", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (confirm != MessageBoxResult.Yes) return;

            _examVm?.Abandon();

            // Quay tro lai man hinh dang nhap
            new LoginWindow { DataContext = new AuthViewModel() }.Show();
            _ownerWindow.Close();
        }
    }
}
