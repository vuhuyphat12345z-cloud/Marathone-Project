﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using MarathoneUI.Models;
using MarathoneUI.Services;
using MarathoneUI.ViewModels.Support;
using MarathoneUI.Views;

namespace MarathoneUI.ViewModels.Xuly
{
    /// <summary>
    /// ViewModel màn hình LỊCH SỬ THI của sinh viên.
    /// Phiên bản hoàn chỉnh:
    ///  + Bảng lịch sử đầy đủ các thông tin CSDL có (mã, thời gian, số câu,
    ///    số câu đúng, điểm, trạng thái nộp bài).
    ///  + Dòng TỔNG QUAN: số bài đã nộp, điểm cao nhất, điểm trung bình.
    ///  + Nút XEM CHI TIẾT: mở cửa sổ chi tiết từng câu đúng/sai của bài đã nộp.
    /// </summary>
    public class ResultViewModel : BaseViewModel
    {
        private readonly ExamService _examService;
        private readonly int _userId;
        private ObservableCollection<ExamHistoryItem> _examHistory;
        private ExamHistoryItem _selectedExam;
        private string _summaryText;

        public ObservableCollection<ExamHistoryItem> ExamHistory
        {
            get => _examHistory;
            set { _examHistory = value; OnPropertyChanged(); }
        }

        /// <summary>Bài thi đang bôi đen trong bảng (dùng cho nút xem chi tiết).</summary>
        public ExamHistoryItem SelectedExam
        {
            get => _selectedExam;
            set { _selectedExam = value; OnPropertyChanged(); }
        }

        /// <summary>Dòng tổng quan kết quả cá nhân.</summary>
        public string SummaryText
        {
            get => _summaryText;
            set { _summaryText = value; OnPropertyChanged(); }
        }

        public ICommand ViewDetailCommand { get; }
        public ICommand RefreshCommand { get; }

        public ResultViewModel(int userId)
        {
            _userId = userId;
            _examService = new ExamService(userId);

            ViewDetailCommand = new RelayCommand(_ => ExecuteViewDetail(),
                                                 _ => SelectedExam != null);
            RefreshCommand = new RelayCommand(_ => LoadHistory());

            LoadHistory();
        }

        private void LoadHistory()
        {
            var historyList = _examService.GetExamHistory();
            ExamHistory = new ObservableCollection<ExamHistoryItem>(historyList);

            // Tính tổng quan từ các bài ĐÃ NỘP
            var completed = historyList.Where(h => h.IsCompleted).ToList();
            if (completed.Count > 0)
            {
                double best = completed.Max(h => h.Score);
                double avg = Math.Round(completed.Average(h => h.Score), 2);
                int earnedBadges = 0;
                int totalBadges = 0;
                try
                {
                    earnedBadges = BadgeService.CountEarned(_userId);
                    totalBadges = BadgeService.CountTotal();
                }
                catch { /* CSDL chưa có bảng huy hiệu thì bỏ qua phần đếm */ }

                SummaryText =
                    $"Đã nộp {completed.Count} bài  •  Điểm cao nhất: {best:0.0}/10  •  Điểm trung bình: {avg:0.00}/10" +
                    (totalBadges > 0 ? $"  •  Huy hiệu: {earnedBadges}/{totalBadges}" : "");
            }
            else
            {
                SummaryText = "Bạn chưa nộp bài thi nào — bấm THI LÀM BÀI ở menu bên trái để bắt đầu!";
            }
        }

        /// <summary>XEM CHI TIẾT bài thi đã chọn trong bảng.</summary>
        private void ExecuteViewDetail()
        {
            ExamHistoryItem target = SelectedExam;
            if (target == null)
            {
                MessageBox.Show("Vui lòng chọn một bài thi trong bảng trước khi xem chi tiết!",
                    "Chưa chọn bài thi", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (!target.IsCompleted)
            {
                MessageBox.Show(
                    "Bài thi này bạn CHƯA NỘP BÀI nên chưa có kết quả chi tiết!\n" +
                    "Hãy quay lại màn THI LÀM BÀI để tiếp tục và nộp bài.",
                    "Bài thi chưa hoàn thành", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var review = new ExamReviewWindow(target.ExamId, _userId)
            {
                Owner = Application.Current?.MainWindow
            };
            review.ShowDialog();
        }
    }
}
