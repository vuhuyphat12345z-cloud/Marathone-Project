﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using MarathoneUI.Models;
using MarathoneUI.Services;
using MarathoneUI.Views;
using MarathoneUI.ViewModels.Support;

namespace MarathoneUI.ViewModels.Xuly
{
    /// <summary>
    /// ViewModel cua man hinh dang nhap.
    /// Da tinh chinh: truyen thong tin user dang nhap vao MainWindow de khoi tao
    /// MainViewModel (truoc day MainWindow khong co DataContext -> man hinh trang,
    /// nut bam chet), bo sung lenh mo man hinh Dang ky va kiem tra ket noi CSDL.
    /// </summary>
    public class AuthViewModel : BaseViewModel
    {
        private string _username;
        private string _errorMessage;

        public string Username
        {
            get => _username;
            set { _username = value; OnPropertyChanged(); }
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            set { _errorMessage = value; OnPropertyChanged(); }
        }

        public ICommand LoginCommand { get; }
        public ICommand RegisterCommand { get; }
        public ICommand TestConnectionCommand { get; }

        public AuthViewModel()
        {
            // Không cần khởi tạo new AuthService() vì AuthService là static
            LoginCommand = new RelayCommand(ExecuteLogin);
            RegisterCommand = new RelayCommand(ExecuteRegister);
            TestConnectionCommand = new RelayCommand(ExecuteTestConnection);
        }

        private void ExecuteLogin(object parameter)
        {
            var passwordBox = parameter as PasswordBox;
            string password = passwordBox?.Password;

            if (string.IsNullOrEmpty(Username) || string.IsNullOrEmpty(password))
            {
                ErrorMessage = "Vui lòng nhập đầy đủ thông tin!";
                return;
            }

            try
            {
                // Gọi phương thức Login kiểu static từ AuthService
                if (AuthService.Login(Username, password, out User loggedInUser))
                {
                    ErrorMessage = string.Empty;

                    // Đăng nhập thành công, mở cửa sổ chính cùng MainViewModel
                    MainWindow mainWindow = new MainWindow();
                    mainWindow.DataContext = new MainViewModel(loggedInUser, mainWindow);
                    mainWindow.Show();

                    // Đóng cửa sổ đăng nhập hiện tại
                    if (parameter is DependencyObject depObj)
                    {
                        Window currentWindow = Window.GetWindow(depObj);
                        currentWindow?.Close();
                    }
                }
                else
                {
                    ErrorMessage = "Tên đăng nhập hoặc mật khẩu không đúng!";
                }
            }
            catch (Exception ex)
            {
                ErrorMessage = "Lỗi đăng nhập: " + ex.Message;
            }
        }

        private void ExecuteRegister(object parameter)
        {
            // Mo man hinh dang ky tai khoan moi
            new RegisterWindow().Show();
        }

        private void ExecuteTestConnection(object parameter)
        {
            // Goi ham kiem tra ket noi CSDL co san trong AuthService
            if (AuthService.TestConnection(out string message))
            {
                MessageBox.Show(message, "Kiểm tra kết nối",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show(message, "Kiểm tra kết nối",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
