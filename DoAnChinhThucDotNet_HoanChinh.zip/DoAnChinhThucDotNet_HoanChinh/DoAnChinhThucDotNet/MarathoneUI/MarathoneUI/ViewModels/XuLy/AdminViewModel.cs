﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using MarathoneUI.Models;
using MarathoneUI.Services;
using MarathoneUI.ViewModels.Support;
using MarathoneUI.Views;

namespace MarathoneUI.ViewModels.Xuly
{
    /// <summary>
    /// ViewModel màn hình Quản trị (Admin) — phiên bản hoàn chỉnh:
    ///  + Tab NGƯỜI DÙNG: xem danh sách tài khoản.
    ///  + Tab CÂU HỎI   : THÊM / SỬA / XÓA / TÌM KIẾM câu hỏi.
    ///  + Tab THỐNG KÊ  : thẻ số liệu tổng hợp, phân bố câu hỏi theo chủ đề,
    ///                    top 10 học viên, lịch sử thi của TẤT CẢ sinh viên
    ///                    (mỗi bài thi có thể bấm XEM CHI TIẾT).
    /// </summary>
    public class AdminViewModel : BaseViewModel
    {
        // Danh sách đầy đủ dùng cho tìm kiếm phía client
        private List<Question> _allQuestions;

        private ObservableCollection<User> _users;
        private ObservableCollection<Question> _questions;
        private Question _selectedQuestion;
        private string _searchText;
        private string _statusText;

        private StatisticsSummary _summary;
        private ObservableCollection<TopicDistributionItem> _topicDistribution;
        private ObservableCollection<TopStudentItem> _topStudents;
        private ObservableCollection<AllExamHistoryItem> _allExams;
        private AllExamHistoryItem _selectedExam;

        public ObservableCollection<User> Users
        {
            get => _users;
            set { _users = value; OnPropertyChanged(); }
        }

        /// <summary>Danh sách câu hỏi ĐANG HIỂN THỊ (đã lọc theo từ khóa nếu có).</summary>
        public ObservableCollection<Question> Questions
        {
            get => _questions;
            set { _questions = value; OnPropertyChanged(); }
        }

        /// <summary>Câu hỏi đang được bôi đen trong bảng (dùng cho SỬA/XÓA).</summary>
        public Question SelectedQuestion
        {
            get => _selectedQuestion;
            set { _selectedQuestion = value; OnPropertyChanged(); }
        }

        /// <summary>Từ khóa tìm kiếm câu hỏi (lọc ngay khi gõ).</summary>
        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value;
                OnPropertyChanged();
                ApplyFilter();
            }
        }

        /// <summary>Thông báo trạng thái ngắn dưới bảng câu hỏi.</summary>
        public string StatusText
        {
            get => _statusText;
            set { _statusText = value; OnPropertyChanged(); }
        }

        // ---------- Dữ liệu tab THỐNG KÊ ----------
        public StatisticsSummary Summary
        {
            get => _summary;
            set { _summary = value; OnPropertyChanged(); }
        }

        public ObservableCollection<TopicDistributionItem> TopicDistribution
        {
            get => _topicDistribution;
            set { _topicDistribution = value; OnPropertyChanged(); }
        }

        public ObservableCollection<TopStudentItem> TopStudents
        {
            get => _topStudents;
            set { _topStudents = value; OnPropertyChanged(); }
        }

        public ObservableCollection<AllExamHistoryItem> AllExams
        {
            get => _allExams;
            set { _allExams = value; OnPropertyChanged(); }
        }

        /// <summary>Bài thi đang bôi đen trong bảng lịch sử của TẤT CẢ sinh viên.</summary>
        public AllExamHistoryItem SelectedExam
        {
            get => _selectedExam;
            set { _selectedExam = value; OnPropertyChanged(); }
        }

        public ICommand RefreshCommand { get; }
        public ICommand AddQuestionCommand { get; }
        public ICommand EditQuestionCommand { get; }
        public ICommand DeleteQuestionCommand { get; }
        public ICommand ClearSearchCommand { get; }
        public ICommand ViewExamDetailCommand { get; }

        public AdminViewModel()
        {
            Users = new ObservableCollection<User>();
            Questions = new ObservableCollection<Question>();
            _allQuestions = new List<Question>();
            TopicDistribution = new ObservableCollection<TopicDistributionItem>();
            TopStudents = new ObservableCollection<TopStudentItem>();
            AllExams = new ObservableCollection<AllExamHistoryItem>();

            RefreshCommand = new RelayCommand(_ => LoadAdminData());
            AddQuestionCommand = new RelayCommand(_ => ExecuteAddQuestion());
            EditQuestionCommand = new RelayCommand(_ => ExecuteEditQuestion(),
                                                   _ => SelectedQuestion != null);
            DeleteQuestionCommand = new RelayCommand(_ => ExecuteDeleteQuestion(),
                                                     _ => SelectedQuestion != null);
            ClearSearchCommand = new RelayCommand(_ => SearchText = "");
            ViewExamDetailCommand = new RelayCommand(p => ExecuteViewExamDetail(p));

            LoadAdminData();
        }

        private void LoadAdminData()
        {
            try
            {
                // ---- Người dùng ----
                Users.Clear();
                foreach (var u in AdminService.GetAllUsers())
                {
                    Users.Add(u);
                }

                // ---- Câu hỏi ----
                _allQuestions = AdminService.GetAllQuestions();
                ApplyFilter();

                // ---- Thống kê ----
                Summary = AdminService.GetStatistics();

                TopicDistribution.Clear();
                foreach (var t in AdminService.GetTopicDistribution())
                {
                    TopicDistribution.Add(t);
                }

                TopStudents.Clear();
                foreach (var s in AdminService.GetTopStudents())
                {
                    TopStudents.Add(s);
                }

                AllExams.Clear();
                foreach (var e in AdminService.GetAllExamHistory())
                {
                    AllExams.Add(e);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể tải dữ liệu quản trị:\n" + ex.Message,
                    "Lỗi tải dữ liệu", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>Lọc danh sách câu hỏi hiển thị theo SearchText.</summary>
        private void ApplyFilter()
        {
            string key = (_searchText ?? "").Trim().ToLowerInvariant();

            IEnumerable<Question> source = _allQuestions ?? Enumerable.Empty<Question>();
            if (key.Length > 0)
            {
                source = source.Where(q =>
                    (q.Content ?? "").ToLowerInvariant().Contains(key) ||
                    (q.Topic ?? "").ToLowerInvariant().Contains(key) ||
                    q.QuestionId.ToString().Equals(key) ||
                    (q.BloomLevel ?? "").ToLowerInvariant().Contains(key));
            }

            var filtered = source.ToList();
            Questions = new ObservableCollection<Question>(filtered);
            StatusText = (key.Length > 0)
                ? $"Tìm thấy {filtered.Count}/{_allQuestions.Count} câu hỏi khớp từ khóa \"{_searchText.Trim()}\"."
                : $"Đang quản lý {_allQuestions.Count} câu hỏi trong ngân hàng.";
        }

        /// <summary>THÊM CÂU HỎI: mở cửa sổ soạn câu hỏi mới (modal dialog).</summary>
        private void ExecuteAddQuestion()
        {
            var editor = new QuestionEditorWindow
            {
                Owner = Application.Current?.MainWindow
            };

            bool? result = editor.ShowDialog();
            if (result == true)
            {
                // Lưu thành công -> tải lại để thấy câu hỏi mới với mã đúng
                LoadAdminData();
                StatusText = "Đã thêm câu hỏi mới vào ngân hàng câu hỏi thành công!";
            }
        }

        /// <summary>SỬA CÂU HỎI đã chọn: mở cửa sổ soạn kèm dữ liệu hiện có.</summary>
        private void ExecuteEditQuestion()
        {
            Question target = SelectedQuestion;
            if (target == null)
            {
                MessageBox.Show("Vui lòng chọn một câu hỏi trong bảng trước khi sửa!",
                    "Chưa chọn câu hỏi", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var editor = new QuestionEditorWindow(target)
            {
                Owner = Application.Current?.MainWindow
            };

            bool? result = editor.ShowDialog();
            if (result == true)
            {
                LoadAdminData();
                StatusText = $"Đã cập nhật câu hỏi [Mã {target.QuestionId}] thành công!";
            }
        }

        /// <summary>XÓA CÂU HỎI đã chọn trong bảng (có xác nhận trước khi xóa).</summary>
        private void ExecuteDeleteQuestion()
        {
            Question target = SelectedQuestion;
            if (target == null)
            {
                MessageBox.Show("Vui lòng chọn một câu hỏi trong bảng trước khi xóa!",
                    "Chưa chọn câu hỏi", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var confirm = MessageBox.Show(
                "Bạn có chắc muốn xóa câu hỏi này không?\n\n" +
                $"[Mã {target.QuestionId}] {target.ShortContent}\n\n" +
                "Mọi đáp án và dữ liệu bài thi liên quan đến câu hỏi này\n" +
                "cũng sẽ bị xóa vĩnh viễn và không thể khôi phục!",
                "Xác nhận xóa câu hỏi",
                MessageBoxButton.YesNo, MessageBoxImage.Warning,
                MessageBoxResult.No);

            if (confirm != MessageBoxResult.Yes) return;

            if (AdminService.DeleteQuestion(target.QuestionId, out string error))
            {
                MessageBox.Show("Đã xóa câu hỏi thành công!",
                    "Xóa thành công", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadAdminData();
            }
            else
            {
                MessageBox.Show(error,
                    "Xóa thất bại", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>XEM CHI TIẾT một bài thi trong tab THỐNG KÊ (mở cửa sổ review).</summary>
        private void ExecuteViewExamDetail(object parameter)
        {
            AllExamHistoryItem target = SelectedExam;
            if (target == null)
            {
                MessageBox.Show("Vui lòng chọn một bài thi trong bảng trước khi xem chi tiết!",
                    "Chưa chọn bài thi", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (!target.IsCompleted)
            {
                MessageBox.Show(
                    "Bài thi này CHƯA NỘP BÀI nên chưa có kết quả chi tiết để xem!\n" +
                    "Chi tiết câu đúng/sai chỉ khả dụng sau khi sinh viên nộp bài.",
                    "Bài thi chưa hoàn thành", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var review = new ExamReviewWindow(target.ExamId, null)
            {
                Owner = Application.Current?.MainWindow
            };
            review.ShowDialog();
        }
    }
}
