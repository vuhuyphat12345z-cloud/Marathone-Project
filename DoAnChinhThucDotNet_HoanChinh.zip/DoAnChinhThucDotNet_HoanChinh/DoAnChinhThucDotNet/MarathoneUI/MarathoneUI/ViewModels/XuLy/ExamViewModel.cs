﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using MarathoneUI.Models;
using MarathoneUI.Services;
using MarathoneUI.ViewModels.Support;
using MarathoneUI.Views;

namespace MarathoneUI.ViewModels.Xuly
{
    /// <summary>
    /// Đóng gói một phương án trả lời trên màn hình thi.
    /// Trường IsSelected để phục hồi lựa chọn khi người thi quay lại câu trước.
    /// </summary>
    public class ExamOptionItem
    {
        public int QuestionId { get; set; }
        public int OptionId { get; set; }
        public string OptionText { get; set; }
        public bool IsCorrect { get; set; }
        public bool IsSelected { get; set; }
    }

    /// <summary>
    /// ViewModel của phiên thi Marathon 50 câu.
    /// Đã tinh chỉnh:
    ///  + Ghi nhận đáp án từng câu và lưu xuống bảng ExamDetails ngay khi chọn.
    ///  + Nộp bài tính điểm thật theo số câu đúng (thang điểm 10).
    ///  + Nút NỘP BÀI luôn hỏi xác nhận trước; hết giờ tự động nộp không cần xác nhận.
    ///  + Phát sự kiện ExamFinished để MainWindow tự chuyển sang màn kết quả.
    ///  + Hỗ trợ quay lại câu trước vẫn giữ đúng lựa chọn đã chọn.
    ///  + Số câu trong phiên thi khớp số câu tải được thực tế (ngân hàng có thể
    ///    ít hơn 50 câu nếu Admin đã xóa bớt) và chống lỗi ngân hàng trống.
    /// </summary>
    public class ExamViewModel : BaseViewModel
    {
        private readonly ExamService _examService;
        private readonly int _userId;
        private Question _currentQuestion;
        private int _currentIndex;
        private string _timeRemaining;
        private DispatcherTimer _timer;
        private int _totalSeconds = 1800; // 30 phút làm bài
        private int _currentExamId;
        private bool _submitted;

        // Ghi nhận đáp án đã chọn theo QuestionId (để phục hồi khi Prev/Next)
        private readonly Dictionary<int, ExamOptionItem> _answers = new Dictionary<int, ExamOptionItem>();

        /// <summary>Phát ra khi bài thi đã được nộp (hết giờ hoặc bấm NỘP BÀI).</summary>
        public event Action ExamFinished;

        public ObservableCollection<Question> Questions { get; set; }
        public ObservableCollection<ExamOptionItem> CurrentOptions { get; set; }

        public Question CurrentQuestion
        {
            get => _currentQuestion;
            set
            {
                _currentQuestion = value;
                OnPropertyChanged();
                if (_currentQuestion != null)
                {
                    LoadOptionsForCurrentQuestion();
                }
            }
        }

        public string TimeRemaining
        {
            get => _timeRemaining;
            set { _timeRemaining = value; OnPropertyChanged(); }
        }

        /// <summary>Tiến độ câu hiện tại, ví dụ: "Câu 7/50".</summary>
        public string ProgressText => $"Câu {_currentIndex + 1}/{Questions?.Count ?? 0}";

        /// <summary>Tổng số câu của bài thi hiện tại.</summary>
        public int TotalCount => Questions?.Count ?? 0;

        /// <summary>Bộ đếm đã trả lời, ví dụ: "Đã trả lời: 12/50".</summary>
        public string AnsweredText => $"ĐÃ TRẢ LỜI: {AnsweredCount}/{TotalCount}";

        /// <summary>Số câu đã trả lời, hiển thị gợi ý cho người thi.</summary>
        public int AnsweredCount => _answers.Count;

        /// <summary>Bài thi đã nộp chưa (chống tạo lại phiên thi khi đang làm dở).</summary>
        public bool IsSubmitted => _submitted;

        public ICommand NextCommand { get; }
        public ICommand PrevCommand { get; }
        public ICommand SubmitCommand { get; }
        public ICommand SaveAnswerCommand { get; }

        // Nhận vào userId của người dùng đang đăng nhập
        public ExamViewModel(int userId)
        {
            _userId = userId;
            _examService = new ExamService(userId);
            CurrentOptions = new ObservableCollection<ExamOptionItem>();
            Questions = new ObservableCollection<Question>();

            NextCommand = new RelayCommand(ExecuteNext, CanExecuteNext);
            PrevCommand = new RelayCommand(ExecutePrev, CanExecutePrev);
            // Nút NỘP BÀI: luôn hỏi xác nhận trước khi chốt điểm
            SubmitCommand = new RelayCommand(ExecuteSubmitClick, _ => !_submitted);
            SaveAnswerCommand = new RelayCommand(ExecuteSaveAnswer);

            // Tải câu hỏi TRƯỚC để biết số câu thực tế (ngân hàng có thể ít hơn 50
            // câu nếu Admin đã xóa bớt) rồi mới tạo phiên thi khớp với số câu đó.
            LoadQuestions();

            if (Questions.Count < 50)
            {
                // CSDL yêu cầu TotalQuestions tối thiểu 50 (CHECK constraint) và
                // đề thi Marathon cần đủ 50 câu mới có ý nghĩa.
                TimeRemaining = "--:--";
                string reason = Questions.Count == 0
                    ? "Ngân hàng câu hỏi hiện đang trống nên không thể làm bài!"
                    : $"Ngân hàng câu hỏi chỉ còn {Questions.Count} câu (cần tối thiểu 50 câu) nên không thể làm bài!";
                MessageBox.Show(
                    reason + "\nVui lòng liên hệ giáo viên/quản trị viên để bổ sung câu hỏi.",
                    "Không thể bắt đầu bài thi", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Khởi tạo phiên thi mới trên CSDL (INSERT MarathonExams, IsCompleted = 0)
            _currentExamId = _examService.CreateNewExamSession(Questions.Count);

            InitTimer();
        }

        private void LoadQuestions()
        {
            try
            {
                var list = _examService.GetRandomQuestions(50);
                Questions = new ObservableCollection<Question>(list);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không thể tải câu hỏi từ cơ sở dữ liệu:\n" + ex.Message,
                    "Lỗi tải câu hỏi", MessageBoxButton.OK, MessageBoxImage.Error);
                Questions = new ObservableCollection<Question>();
            }
            OnPropertyChanged(nameof(Questions));
            OnPropertyChanged(nameof(ProgressText));
            OnPropertyChanged(nameof(TotalCount));
            OnPropertyChanged(nameof(AnsweredText));
        }

        private void LoadOptionsForCurrentQuestion()
        {
            if (_currentQuestion == null) return;

            var opts = _examService.GetOptionsForQuestion(_currentQuestion.QuestionId);
            CurrentOptions.Clear();
            foreach (var opt in opts)
            {
                // Phục hồi trạng thái đã chọn nếu người thi trả lời câu này rồi
                bool isSelected = _answers.TryGetValue(_currentQuestion.QuestionId, out var chosen)
                                  && chosen.OptionId == opt.OptionId;

                CurrentOptions.Add(new ExamOptionItem
                {
                    QuestionId = _currentQuestion.QuestionId,
                    OptionId = opt.OptionId,
                    OptionText = opt.OptionText,
                    IsCorrect = opt.IsCorrect,
                    IsSelected = isSelected
                });
            }
        }

        /// <summary>Chạy mỗi lần người thi tick chọn một phương án: lưu vào ExamDetails.</summary>
        private void ExecuteSaveAnswer(object parameter)
        {
            if (_submitted) return;
            if (parameter is not ExamOptionItem item || !item.IsSelected) return;
            if (_currentQuestion == null || item.QuestionId != _currentQuestion.QuestionId) return;

            _answers[item.QuestionId] = item;
            OnPropertyChanged(nameof(AnsweredCount));
            OnPropertyChanged(nameof(AnsweredText));

            try
            {
                // Lưu ngay chi tiết câu trả lời (upsert: đổi đáp án sẽ ghi đè lần trước)
                _examService.SaveExamDetail(
                    _currentExamId,
                    item.QuestionId,
                    item.OptionId,
                    item.IsCorrect,
                    _currentQuestion.BloomLevel);
            }
            catch (Exception ex)
            {
                // Không làm gián đoạn làm bài khi lưu lỗi, chỉ ghi log để theo dõi
                System.Diagnostics.Debug.WriteLine("Lưu câu trả lời thất bại: " + ex.Message);
            }
        }

        private void InitTimer()
        {
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromSeconds(1);
            _timer.Tick += (s, e) =>
            {
                if (_totalSeconds > 0)
                {
                    _totalSeconds--;
                    int mins = _totalSeconds / 60;
                    int secs = _totalSeconds % 60;
                    TimeRemaining = $"{mins:D2}:{secs:D2}";
                }
                else
                {
                    // Hết giờ -> tự động nộp bài, KHÔNG hỏi xác nhận
                    _timer.Stop();
                    MessageBox.Show(
                        "Đã hết thời gian làm bài (30 phút)!\nHệ thống sẽ tự động nộp bài của bạn.",
                        "Hết giờ làm bài", MessageBoxButton.OK, MessageBoxImage.Warning);
                    DoSubmit();
                }
            };
            _timer.Start();
            TimeRemaining = "30:00";
        }

        private bool CanExecuteNext(object obj) => _currentIndex < Questions.Count - 1;
        private void ExecuteNext(object obj)
        {
            if (_currentIndex < Questions.Count - 1)
            {
                _currentIndex++;
                CurrentQuestion = Questions[_currentIndex];
                OnPropertyChanged(nameof(ProgressText));
            }
        }

        private bool CanExecutePrev(object obj) => _currentIndex > 0;
        private void ExecutePrev(object obj)
        {
            if (_currentIndex > 0)
            {
                _currentIndex--;
                CurrentQuestion = Questions[_currentIndex];
                OnPropertyChanged(nameof(ProgressText));
            }
        }

        /// <summary>Nút NỘP BÀI trên màn hình: hỏi xác nhận trước khi chốt điểm.</summary>
        private void ExecuteSubmitClick(object obj)
        {
            if (_submitted) return;

            int total = Questions?.Count ?? 0;
            int answered = _answers.Count;
            int unanswered = total - answered;

            string notice = unanswered > 0
                ? $"Bạn còn {unanswered} câu chưa trả lời!\n\n"
                : "Bạn đã trả lời tất cả các câu.\n\n";

            var confirm = MessageBox.Show(
                notice +
                "Bạn có chắc muốn nộp bài không?\n" +
                "Sau khi nộp bài bạn sẽ KHÔNG THỂ quay lại sửa đáp án!",
                "Xác nhận nộp bài", MessageBoxButton.YesNo, MessageBoxImage.Question,
                MessageBoxResult.No);

            if (confirm != MessageBoxResult.Yes) return;

            DoSubmit();
        }

        private void DoSubmit()
        {
            if (_submitted) return;
            _submitted = true;
            _timer?.Stop();

            // Tính điểm dự phòng phía client, sau đó lấy kết quả CHÍNH THỨC
            // từ thủ tục sp_SubmitExam của CSDL (chấm lại từ bảng ExamDetails,
            // cập nhật EndTime/CorrectAnswers/Score/IsCompleted đầy đủ).
            int total = Questions?.Count ?? 0;
            int correct = _answers.Values.Count(a => a.IsCorrect);
            double score = total > 0 ? Math.Round(correct * 10.0 / total, 1) : 0;

            try
            {
                var result = _examService.SubmitExam(_currentExamId);
                if (result.TotalQuestions > 0)
                {
                    total = result.TotalQuestions;
                    correct = result.CorrectAnswers;
                    score = result.Score;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không thể lưu kết quả bài thi vào cơ sở dữ liệu:\n" + ex.Message,
                    "Lỗi lưu kết quả", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            MessageBox.Show(
                $"Bạn đã nộp bài thành công!\n\n" +
                $"Số câu đúng: {correct}/{total}\n" +
                $"Điểm: {score:0.0}/10",
                "Kết quả bài thi", MessageBoxButton.OK, MessageBoxImage.Information);

            // Trao huy hiệu tự động sau khi nộp bài (sp_AwardBadges của CSDL):
            // điểm >= 8 -> HUY HIỆU VÀNG, 10/10 -> hoàn hảo, đủ 5 bài -> kiên trì...
            try
            {
                var newBadges = BadgeService.EvaluateAndAward(_userId, _currentExamId);
                if (newBadges.Count > 0)
                {
                    // Cửa sổ chúc mừng liệt kê huy hiệu vừa nhận
                    new BadgeEarnedWindow(newBadges)
                    {
                        Owner = Application.Current?.MainWindow
                    }.ShowDialog();
                }
            }
            catch (Exception badgeEx)
            {
                // Không chặn luồng kết quả bài thi nếu trao huy hiệu gặp lỗi
                System.Diagnostics.Debug.WriteLine("Trao huy hiệu thất bại: " + badgeEx.Message);
            }

            // Báo cho MainWindow chuyển sang màn hình kết quả/lịch sử
            ExamFinished?.Invoke();
        }

        /// <summary>
        /// Gọi khi rời khỏi màn hình thi mà không nộp bài (điều hướng sang màn khác).
        /// Dừng đồng hồ để tránh việc timer tự động nộp bài trong nền.
        /// </summary>
        public void Abandon()
        {
            _timer?.Stop();
        }
    }
}
