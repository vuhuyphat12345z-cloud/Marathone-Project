﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using MarathoneUI.Models;
using MarathoneUI.Services;
using MarathoneUI.ViewModels.Support;

namespace MarathoneUI.ViewModels.Xuly
{
    /// <summary>
    /// ViewModel cửa sổ XEM CHI TIẾT BÀI THI: hiển thị từng câu hỏi trong bài,
    /// đáp án người thi đã chọn, đáp án đúng và kết quả ĐÚNG/SAI.
    ///  + Sinh viên xem bài của mình  : userIdFilter = mã của họ (kiểm tra quyền).
    ///  + Admin xem bất kỳ bài thi nào: userIdFilter = null.
    /// </summary>
    public class ExamReviewViewModel : BaseViewModel
    {
        private ObservableCollection<ExamReviewItem> _items;

        public int ExamId { get; }
        public DateTime StartTime { get; }
        public double Score { get; }

        public string TitleText => $"CHI TIẾT BÀI THI [MÃ {ExamId}]";
        public string ScoreText => $"Điểm: {Score:0.0}/10";

        /// <summary>Số câu đúng / tổng số câu có trong chi tiết bài thi.</summary>
        public string SummaryText
        {
            get
            {
                int total = _items?.Count ?? 0;
                int correct = (_items ?? Enumerable.Empty<ExamReviewItem>()).Count(i => i.IsCorrect);
                return $"Số câu đúng: {correct}/{total}";
            }
        }

        public ObservableCollection<ExamReviewItem> Items
        {
            get => _items;
            set { _items = value; OnPropertyChanged(); OnPropertyChanged(nameof(SummaryText)); }
        }

        /// <param name="examId">Mã bài thi cần xem chi tiết.</param>
        /// <param name="userIdFilter">Mã sinh viên (nếu là sinh viên xem bài của mình), null nếu Admin.</param>
        /// <param name="startTime">Thời gian bắt đầu bài thi (hiển thị phụ đề).</param>
        /// <param name="score">Điểm đã chốt của bài thi.</param>
        public ExamReviewViewModel(int examId, int? userIdFilter, DateTime startTime, double score)
        {
            ExamId = examId;
            StartTime = startTime;
            Score = score;

            Items = new ObservableCollection<ExamReviewItem>();
            LoadDetails(userIdFilter);
        }

        private void LoadDetails(int? userIdFilter)
        {
            try
            {
                List<ExamReviewItem> details = ExamService.GetExamDetails(ExamId, userIdFilter);

                // Đánh số thứ tự câu hỏi cho dễ theo dõi khi đọc
                Items = new ObservableCollection<ExamReviewItem>(details);
            }
            catch (UnauthorizedAccessException)
            {
                throw; // để cửa sổ bắt và thông báo quyền truy cập
            }
            catch (Exception ex)
            {
                throw new Exception("Không thể tải chi tiết bài thi: " + ex.Message, ex);
            }
        }
    }
}
