﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using MarathoneUI.Models;
using MarathoneUI.Services;
using MarathoneUI.ViewModels.Support;

namespace MarathoneUI.ViewModels.Xuly
{
    /// <summary>
    /// Một dòng đáp án trong cửa sổ soạn câu hỏi.
    /// Kế thừa BaseViewModel để khi bấm chọn "đáp án đúng" nút radio
    /// được cập nhật lại giao diện ngay lập tức.
    /// </summary>
    public class EditorOption : BaseViewModel
    {
        private string _optionText;
        private bool _isCorrect;

        public string OptionText
        {
            get => _optionText;
            set { _optionText = value; OnPropertyChanged(); }
        }

        public bool IsCorrect
        {
            get => _isCorrect;
            set { _isCorrect = value; OnPropertyChanged(); }
        }
    }

    /// <summary>
    /// ViewModel của cửa sổ soạn câu hỏi (dành cho Admin), dùng cho CẢ 2 chế độ:
    ///  + THÊM MỚI: constructor không tham số, lưu bằng AdminService.AddQuestion.
    ///  + SỬA    : constructor nhận Question, tải nội dung + đáp án hiện có lên,
    ///             lưu bằng AdminService.UpdateQuestion.
    /// Số đáp án linh hoạt 2-6 (khớp thiết kế CSDL), chọn đúng 1 đáp án đúng.
    /// </summary>
    public class QuestionEditorViewModel : BaseViewModel
    {
        private readonly int? _editingQuestionId;   // null = đang THÊM mới

        private string _content;
        private string _topic;
        private string _selectedBloomLevel;
        private string _errorMessage;

        /// <summary>Các mức nhận thức khớp CHECK constraint CHK_Questions_Bloom.</summary>
        public string[] BloomLevels => AdminService.BloomLevels;

        public string Content
        {
            get => _content;
            set { _content = value; OnPropertyChanged(); }
        }

        public string Topic
        {
            get => _topic;
            set { _topic = value; OnPropertyChanged(); }
        }

        public string SelectedBloomLevel
        {
            get => _selectedBloomLevel;
            set { _selectedBloomLevel = value; OnPropertyChanged(); }
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            set { _errorMessage = value; OnPropertyChanged(); }
        }

        /// <summary>Tiêu đề cửa sổ thay đổi theo chế độ THÊM/SỬA.</summary>
        public string WindowTitle => _editingQuestionId.HasValue
            ? $"SỬA CÂU HỎI [Mã {_editingQuestionId.Value}]"
            : "THÊM CÂU HỎI MỚI";

        /// <summary>Bốn đáp án của câu hỏi (A, B, C, D).</summary>
        public ObservableCollection<EditorOption> Options { get; }

        /// <summary>Được phép thêm đáp án nữa không (tối đa 6).</summary>
        public bool CanAddOption => Options.Count < 6;

        public ICommand SetCorrectOptionCommand { get; private set; }
        public ICommand AddOptionCommand { get; private set; }
        public ICommand RemoveOptionCommand { get; private set; }
        public ICommand SaveCommand { get; private set; }
        public ICommand CancelCommand { get; private set; }

        // ---------- CHẾ ĐỘ 1: THÊM CÂU HỎI MỚI ----------
        public QuestionEditorViewModel()
        {
            Options = new ObservableCollection<EditorOption>
            {
                new EditorOption { OptionText = "", IsCorrect = true  },
                new EditorOption { OptionText = "", IsCorrect = false },
                new EditorOption { OptionText = "", IsCorrect = false },
                new EditorOption { OptionText = "", IsCorrect = false }
            };

            SelectedBloomLevel = "Nhớ";
            WireCommands();
        }

        // ---------- CHẾ ĐỘ 2: SỬA CÂU HỎI CÓ SẴN ----------
        public QuestionEditorViewModel(Question existing)
        {
            if (existing == null) throw new ArgumentNullException(nameof(existing));
            _editingQuestionId = existing.QuestionId;

            Content = existing.Content;
            Topic = existing.Topic;
            SelectedBloomLevel = Array.IndexOf(AdminService.BloomLevels, existing.BloomLevel) >= 0
                ? existing.BloomLevel
                : AdminService.BloomLevels[0];

            // Tải đáp án hiện có của câu hỏi từ CSDL; nếu ít hơn 4 thì bổ sung dòng trống
            var loaded = AdminService.GetOptionsForQuestion(existing.QuestionId)
                         .OrderBy(o => o.OptionId)
                         .Select(o => new EditorOption { OptionText = o.OptionText, IsCorrect = o.IsCorrect })
                         .ToList();

            while (loaded.Count < 4)
            {
                loaded.Add(new EditorOption { OptionText = "", IsCorrect = false });
            }

            // Nếu câu hỏi này không có đáp án nào được đánh dấu đúng (dữ liệu lệch)
            // thì tạm chọn đáp án đầu tiên để trạng thái giao diện luôn hợp lệ
            if (!loaded.Any(o => o.IsCorrect) && loaded.Count > 0)
            {
                loaded[0].IsCorrect = true;
            }

            Options = new ObservableCollection<EditorOption>(loaded);
            WireCommands();
        }

        private void WireCommands()
        {
            SetCorrectOptionCommand = new RelayCommand(ExecuteSetCorrectOption);
            AddOptionCommand = new RelayCommand(_ => ExecuteAddOption(), _ => CanAddOption);
            RemoveOptionCommand = new RelayCommand(ExecuteRemoveOption);
            SaveCommand = new RelayCommand(ExecuteSave);
            CancelCommand = new RelayCommand(ExecuteCancel);

            Options.CollectionChanged += (s, e) => OnPropertyChanged(nameof(CanAddOption));
        }

        /// <summary>Bấm chọn radio của một đáp án -> chỉ đáp án đó là đúng.</summary>
        private void ExecuteSetCorrectOption(object parameter)
        {
            if (parameter is not EditorOption chosen) return;

            foreach (var opt in Options)
            {
                opt.IsCorrect = ReferenceEquals(opt, chosen);
            }
        }

        /// <summary>Thêm một dòng đáp án trống (tối đa 6 dòng).</summary>
        private void ExecuteAddOption()
        {
            if (Options.Count >= 6)
            {
                ErrorMessage = "Một câu hỏi chỉ được có tối đa 6 đáp án!";
                return;
            }
            Options.Add(new EditorOption { OptionText = "", IsCorrect = false });
            OnPropertyChanged(nameof(CanAddOption));
        }

        /// <summary>Xóa một dòng đáp án (còn lại tối thiểu 2 dòng).</summary>
        private void ExecuteRemoveOption(object parameter)
        {
            if (parameter is not EditorOption opt) return;
            if (Options.Count <= 2)
            {
                ErrorMessage = "Câu hỏi phải có ít nhất 2 đáp án!";
                return;
            }
            if (opt.IsCorrect && Options.Count > 1)
            {
                // Chuyển "đáp án đúng" sang dòng còn lại trước khi xóa
                var next = Options.FirstOrDefault(o => !ReferenceEquals(o, opt));
                if (next != null) next.IsCorrect = true;
            }
            Options.Remove(opt);
            OnPropertyChanged(nameof(CanAddOption));
        }

        private void ExecuteSave(object parameter)
        {
            ErrorMessage = string.Empty;

            // ---- 1. Kiểm tra dữ liệu nhập (thông báo bằng tiếng Việt) ----
            if (string.IsNullOrWhiteSpace(Content))
            {
                ErrorMessage = "Vui lòng nhập nội dung câu hỏi!";
                return;
            }

            if (string.IsNullOrWhiteSpace(Topic))
            {
                ErrorMessage = "Vui lòng nhập chủ đề câu hỏi (ví dụ: Stack, Sorting, Graph...)!";
                return;
            }

            if (Options.Count(o => string.IsNullOrWhiteSpace(o.OptionText)) > 0)
            {
                ErrorMessage = "Vui lòng nhập đầy đủ nội dung của tất cả các đáp án (hoặc xóa bớt dòng trống)!";
                return;
            }

            if (Options.Count(o => o.IsCorrect) != 1)
            {
                ErrorMessage = "Câu hỏi phải có ĐÚNG MỘT đáp án đúng!";
                return;
            }

            var optionList = Options.Select(o => new QuestionOption
            {
                OptionText = o.OptionText,
                IsCorrect = o.IsCorrect
            }).ToList();

            // ---- 2. Gọi dịch vụ lưu xuống CSDL (THÊM hoặc SỬA) ----
            if (_editingQuestionId.HasValue)
            {
                bool ok = AdminService.UpdateQuestion(
                    _editingQuestionId.Value, Content, Topic, SelectedBloomLevel,
                    optionList, out string updateError);

                if (!ok)
                {
                    ErrorMessage = string.IsNullOrEmpty(updateError)
                        ? "Cập nhật câu hỏi thất bại, vui lòng thử lại!"
                        : updateError;
                    return;
                }

                MessageBox.Show(
                    $"Đã cập nhật câu hỏi [Mã {_editingQuestionId.Value}] thành công!",
                    "Sửa câu hỏi thành công",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                int newId = AdminService.AddQuestion(
                    Content, Topic, SelectedBloomLevel, optionList, out string error);

                if (newId == -1)
                {
                    ErrorMessage = string.IsNullOrEmpty(error)
                        ? "Lưu câu hỏi thất bại, vui lòng thử lại!"
                        : error;
                    return;
                }

                MessageBox.Show(
                    $"Đã thêm câu hỏi mới thành công!\nMã câu hỏi: {newId}",
                    "Thêm câu hỏi thành công",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }

            // ---- 3. Đóng cửa sổ, báo hiệu lưu OK ----
            if (parameter is Window window)
            {
                window.DialogResult = true; // tự đóng cửa sổ
            }
        }

        private void ExecuteCancel(object parameter)
        {
            if (parameter is Window window)
            {
                window.DialogResult = false;
            }
        }
    }
}
