﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using MarathoneUI.Models;
using MarathoneUI.Services;
using MarathoneUI.ViewModels.Support;
using MarathoneUI.Views;

namespace MarathoneUI.ViewModels.Xuly
{
    /// <summary>
    /// ViewModel màn hình HUY HIỆU THÀNH TỰU của sinh viên:
    ///  + Hiển thị toàn bộ danh mục huy hiệu kèm trạng thái ĐÃ NHẬN / CHƯA NHẬN.
    ///  + Huy hiệu chưa nhận hiện mờ kèm điều kiện + tiến độ hiện tại để theo đuổi.
    ///  + Nút làm mới tải lại trạng thái mới nhất từ CSDL.
    /// </summary>
    public class BadgeViewModel : BaseViewModel
    {
        private readonly int _userId;
        private ObservableCollection<BadgeItem> _badges;
        private string _summaryText;
        private string _highlightText;

        public ObservableCollection<BadgeItem> Badges
        {
            get => _badges;
            set { _badges = value; OnPropertyChanged(); }
        }

        /// <summary>Dòng tổng quan: đã đạt bao nhiêu trên tổng số huy hiệu.</summary>
        public string SummaryText
        {
            get => _summaryText;
            set { _summaryText = value; OnPropertyChanged(); }
        }

        /// <summary>Dòng động viên dựa trên huy hiệu gần đạt nhất.</summary>
        public string HighlightText
        {
            get => _highlightText;
            set { _highlightText = value; OnPropertyChanged(); }
        }

        public ICommand RefreshCommand { get; }

        public BadgeViewModel(int userId)
        {
            _userId = userId;
            RefreshCommand = new RelayCommand(_ => LoadBadges());
            LoadBadges();
        }

        private void LoadBadges()
        {
            try
            {
                var list = new BadgeService(_userId).GetUserBadges();
                Badges = new ObservableCollection<BadgeItem>(list);

                int earned = list.Count(b => b.IsEarned);
                int total = list.Count;
                SummaryText = $"🏆 Đã đạt {earned}/{total} huy hiệu thành tựu";

                // Gợi ý huy hiệu gần đạt nhất (đánh giá theo tiến độ phần trăm)
                var nearest = list.Where(b => !b.IsEarned)
                                  .OrderByDescending(b => EstimateProgressPercent(b))
                                  .FirstOrDefault();
                HighlightText = nearest == null
                    ? (total == 0
                        ? "Danh mục huy hiệu chưa được thiết lập trong CSDL — hãy chạy file DATACHINHTHUC.sql!"
                        : "Xuất sắc! Bạn đã sưu tập đủ toàn bộ huy hiệu của hệ thống!")
                    : $"Gần đạt nhất: {nearest.BadgeName} — {nearest.ConditionText}" +
                      (string.IsNullOrEmpty(nearest.ProgressText) ? "" : $" ({nearest.ProgressText})");
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không thể tải danh sách huy hiệu từ cơ sở dữ liệu:\n" + ex.Message +
                    "\n\nHãy chắc chắn đã chạy file DATACHINHTHUC.sql!",
                    "Lỗi tải huy hiệu", MessageBoxButton.OK, MessageBoxImage.Error);
                Badges = new ObservableCollection<BadgeItem>();
                SummaryText = "Không tải được huy hiệu";
                HighlightText = "";
            }
        }

        /// <summary>Ước lượng phần trăm tiến độ của từng huy hiệu để sắp xếp gợi ý.</summary>
        private static double EstimateProgressPercent(BadgeItem b)
        {
            switch (b.IconKey)
            {
                case "first_step": return ParseFraction(b.ProgressText, 1);
                case "persistent": return ParseFraction(b.ProgressText, 5);
                case "gold_score":
                case "perfect":
                    double.TryParse(ExtractNumber(b.ProgressText), out double s);
                    return Math.Min(s / 10.0 * 100, 100);
                case "master":
                    double.TryParse(ExtractNumber(b.ProgressText), out double a);
                    return Math.Min(a / 8.0 * 100, 100);
                default: return 0;
            }
        }

        private static double ParseFraction(string text, int denominator)
        {
            if (string.IsNullOrEmpty(text)) return 0;
            int slash = text.IndexOf('/');
            if (slash <= 0 || !int.TryParse(text.Substring(0, slash).Trim(), out int current))
                return 0;
            return Math.Min(current * 100.0 / denominator, 100);
        }

        private static string ExtractNumber(string text)
        {
            if (string.IsNullOrEmpty(text)) return "0";
            var chars = text.SkipWhile(c => !char.IsDigit(c) && c != '.')
                            .TakeWhile(c => char.IsDigit(c) || c == '.');
            string number = new string(chars.ToArray());
            return string.IsNullOrEmpty(number) ? "0" : number;
        }
    }

    /// <summary>
    /// ViewModel của cửa sổ chúc mừng hiện ngay sau khi nộp bài nếu sinh viên
    /// vừa nhận được huy hiệu mới (danh sách huy hiệu được truyền vào constructor).
    /// </summary>
    public class BadgeEarnedViewModel : BaseViewModel
    {
        public ObservableCollection<BadgeItem> NewBadges { get; }

        public string TitleText =>
            NewBadges.Count == 1
                ? "BẠN VỪA NHẬN ĐƯỢC 1 HUY HIỆU MỚI!"
                : $"BẠN VỪA NHẬN ĐƯỢC {NewBadges.Count} HUY HIỆU MỚI!";

        public BadgeEarnedViewModel(IEnumerable<BadgeItem> newBadges)
        {
            NewBadges = new ObservableCollection<BadgeItem>(newBadges);
        }
    }
}
