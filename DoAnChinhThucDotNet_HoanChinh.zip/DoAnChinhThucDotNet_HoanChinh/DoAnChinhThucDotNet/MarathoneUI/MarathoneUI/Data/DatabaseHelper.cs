﻿namespace MarathoneUI.Data
{
    public static class DatabaseHelper
    {
        // CSDL thực tế của đồ án: DoAnDotNet (theo file DATACHINHTHUC.sql)
        public static readonly string ConnectionString =
            @"Data Source=LAPTOP-J5TG78LN;Initial Catalog=DoAnDotNet;Integrated Security=True;TrustServerCertificate=True;";
    }
}
