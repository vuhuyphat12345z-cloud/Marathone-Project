﻿-- =========================================================================
-- ĐỒ ÁN DOT NET - MARATHON DSA (ÔN TẬP CẤU TRÚC DỮ LIỆU & GIẢI THUẬT)
-- SCRIPT CƠ SỞ DỮ LIỆU HOÀN CHỈNH - GỘP MỘT FILE DUY NHẤT, CHẠY MỘT LẦN
-- =========================================================================
-- NỘI DUNG FILE (TẤT CẢ TRONG MỘT):
--   PHẦN 0: Tạo cơ sở dữ liệu DoAnDotNet (tự bỏ qua nếu CSDL đã tồn tại)
--   PHẦN 1: Tạo 7 bảng (Users, Questions, QuestionOptions, Badges,
--           MarathonExams, ExamDetails, UserBadges)
--   PHẦN 2: Stored procedures nghiệp vụ (sp_RegisterUser, sp_SubmitExam)
--   PHẦN 3: Stored procedure tự động trao huy hiệu (sp_AwardBadges)
--   PHẦN 4: Tài khoản mẫu: admin/123456 - student1/123456
--   PHẦN 5: 50 câu hỏi trắc nghiệm DSA tiếng Việt (200 đáp án)
--   PHẦN 6: Seed 5 huy hiệu (Bước Đầu Tiên, Điểm Giỏi, Điểm Hoàn Hảo,
--           Kiên Trì, Học Bá)
--   PHẦN 7: Dữ liệu mẫu (3 sinh viên + 8 bài thi + huy hiệu đã trao) để
--           màn hình THỐNG KÊ / LỊCH SỬ / HUY HIỆU có sẵn dữ liệu
--   PHẦN 8: Truy vấn kiểm tra kết quả (tùy chọn)

-- CÁCH CHẠY:
--   1. Mở SQL Server Management Studio -> Connect
--   2. New Query -> dán TOÀN BỘ nội dung file -> Execute (F5)
--   3. Mở chương trình WPF (MarathoneUI) và đăng nhập:
--        admin/123456  (Quản trị viên)
--        student1/123456 (Sinh viên - đã có 5/5 huy hiệu trong dữ liệu mẫu)
-- =========================================================================

-- =========================================================================
-- PHẦN 0: TẠO CƠ SỞ DỮ LIỆU (nếu chưa có - chạy lại không bị lỗi)
-- =========================================================================
IF DB_ID(N'DoAnDotNet') IS NULL
    CREATE DATABASE DoAnDotNet;
GO

USE DoAnDotNet
GO

-- =========================================================================
-- PHẦN 1: TẠO CÁC BẢNG (xóa bảng cũ theo thứ tự ngược FK để reset sạch sẽ)
-- =========================================================================
-- Xóa bảng theo thứ tự ngược lại nếu đã tồn tại để reset database sạch sẽ
IF OBJECT_ID('UserBadges', 'U') IS NOT NULL DROP TABLE UserBadges;
IF OBJECT_ID('ExamDetails', 'U') IS NOT NULL DROP TABLE ExamDetails;
IF OBJECT_ID('MarathonExams', 'U') IS NOT NULL DROP TABLE MarathonExams;
IF OBJECT_ID('QuestionOptions', 'U') IS NOT NULL DROP TABLE QuestionOptions;
IF OBJECT_ID('Questions', 'U') IS NOT NULL DROP TABLE Questions;
IF OBJECT_ID('Badges', 'U') IS NOT NULL DROP TABLE Badges;
IF OBJECT_ID('Users', 'U') IS NOT NULL DROP TABLE Users;
GO

-- 1. BẢNG USERS (Người dùng: Admin / Student)
CREATE TABLE Users (
    UserId INT IDENTITY(1,1) PRIMARY KEY,
    Username VARCHAR(50) NOT NULL UNIQUE,          -- UNIQUE: Không trùng tên đăng nhập
    PasswordHash VARCHAR(255) NOT NULL,
    FullName NVARCHAR(100) NOT NULL,
    Class VARCHAR(20) NULL,                        -- Lớp học (dành cho Sinh viên)
    Role VARCHAR(10) NOT NULL DEFAULT 'Student',   -- DEFAULT: Mặc định là Student
    CreatedAt DATETIME DEFAULT GETDATE(),
    
    CONSTRAINT CHK_Users_Role CHECK (Role IN ('Admin', 'Student'))
);

-- 2. BẢNG QUESTIONS (Ngân hàng câu hỏi DSA)
CREATE TABLE Questions (
    QuestionId INT IDENTITY(1,1) PRIMARY KEY,
    Content NVARCHAR(MAX) NOT NULL,
    Topic NVARCHAR(50) NOT NULL,                    -- Chủ đề (Array, BST, Graph,...)
    BloomLevel NVARCHAR(20) NOT NULL,               -- Mức độ Bloom (Nhớ, Hiểu, Vận dụng)
    CreatedAt DATETIME DEFAULT GETDATE(),
    
    CONSTRAINT CHK_Questions_Bloom CHECK (BloomLevel IN (N'Nhớ', N'Hiểu', N'Vận dụng'))
);

-- 3. BẢNG QUESTION_OPTIONS (Các lựa chọn A, B, C, D)
CREATE TABLE QuestionOptions (
    OptionId INT IDENTITY(1,1) PRIMARY KEY,
    QuestionId INT NOT NULL,                        -- Khóa ngoại liên kết câu hỏi
    OptionText NVARCHAR(MAX) NOT NULL,
    IsCorrect BIT NOT NULL DEFAULT 0,               -- 1: Đúng, 0: Sai

    CONSTRAINT FK_Options_Questions FOREIGN KEY (QuestionId) 
        REFERENCES Questions(QuestionId) ON DELETE CASCADE ON UPDATE CASCADE
);

-- 4. BẢNG BADGES (Danh mục huy hiệu)
CREATE TABLE Badges (
    BadgeId INT IDENTITY(1,1) PRIMARY KEY,
    BadgeName NVARCHAR(100) NOT NULL UNIQUE,        -- Tên huy hiệu không trùng
    Description NVARCHAR(255) NULL,
    IconUrl VARCHAR(255) NULL
);

-- 5. BẢNG MARATHON_EXAMS (Lượt thi Quiz của sinh viên)
CREATE TABLE MarathonExams (
    ExamId INT IDENTITY(1,1) PRIMARY KEY,
    UserId INT NOT NULL,                            -- Người tham gia thi
    StartTime DATETIME DEFAULT GETDATE(),
    EndTime DATETIME NULL,
    TotalQuestions INT NOT NULL DEFAULT 50,         -- Số câu (thường 50-100 câu)
    CorrectAnswers INT NOT NULL DEFAULT 0,          -- Số câu trả lời đúng
    Score FLOAT NOT NULL DEFAULT 0.0,               -- Điểm tổng (Thang điểm 10)
    IsCompleted BIT NOT NULL DEFAULT 0,             -- 0: Đang làm, 1: Đã nộp bài

    CONSTRAINT FK_Exams_Users FOREIGN KEY (UserId) 
        REFERENCES Users(UserId) ON DELETE CASCADE,

    CONSTRAINT CHK_Exams_TotalQuestions CHECK (TotalQuestions BETWEEN 50 AND 100),
    CONSTRAINT CHK_Exams_Score CHECK (Score >= 0 AND Score <= 10)
);

-- 6. BẢNG EXAM_DETAILS (Chi tiết bài làm từng câu của sinh viên)
CREATE TABLE ExamDetails (
    DetailId INT IDENTITY(1,1) PRIMARY KEY,
    ExamId INT NOT NULL,                            -- Thuộc bài thi nào
    QuestionId INT NOT NULL,                        -- Đang trả lời câu hỏi nào
    SelectedOptionId INT NULL,                      -- Đáp án người chơi chọn (Null nếu bỏ trống)
    IsCorrect BIT NOT NULL DEFAULT 0,               -- Đúng/Sai
    BloomLevel NVARCHAR(20) NOT NULL,               -- Lưu vết mức Bloom để tính báo cáo

    CONSTRAINT FK_ExamDetails_Exams FOREIGN KEY (ExamId) 
        REFERENCES MarathonExams(ExamId) ON DELETE CASCADE,
        
    CONSTRAINT FK_ExamDetails_Questions FOREIGN KEY (QuestionId) 
        REFERENCES Questions(QuestionId),
        
    CONSTRAINT FK_ExamDetails_Options FOREIGN KEY (SelectedOptionId) 
        REFERENCES QuestionOptions(OptionId) ON DELETE SET NULL,

    CONSTRAINT UQ_Exam_Question UNIQUE (ExamId, QuestionId)
);

-- 7. BẢNG USER_BADGES (Lưu huy hiệu sinh viên đạt được)
CREATE TABLE UserBadges (
    UserBadgeId INT IDENTITY(1,1) PRIMARY KEY,
    UserId INT NOT NULL,                            -- Sinh viên nhận huy hiệu
    BadgeId INT NOT NULL,                           -- Loại huy hiệu
    ExamId INT NULL,                                -- Nhận được từ bài thi nào (nếu có)
    AwardedAt DATETIME DEFAULT GETDATE(),

    CONSTRAINT FK_UserBadges_Users FOREIGN KEY (UserId) 
        REFERENCES Users(UserId) ON DELETE CASCADE,
        
    CONSTRAINT FK_UserBadges_Badges FOREIGN KEY (BadgeId) 
        REFERENCES Badges(BadgeId) ON DELETE CASCADE,
        
    CONSTRAINT FK_UserBadges_Exams FOREIGN KEY (ExamId) 
        REFERENCES MarathonExams(ExamId),

    CONSTRAINT UQ_User_Badge UNIQUE (UserId, BadgeId)
);
GO

-- PHẦN 2: TẠO STORED PROCEDURES HỖ TRỢ NGHIỆP VỤ WPF
-- =========================================================================

-- 1. SP ĐĂNG KÝ TÀI KHOẢN
CREATE PROCEDURE sp_RegisterUser
    @Username VARCHAR(50),
    @PasswordHash VARCHAR(255),
    @FullName NVARCHAR(100),
    @Class VARCHAR(20),
    @Role VARCHAR(10) = 'Student'
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Users WHERE Username = @Username)
    BEGIN
        SELECT -1 AS Result; -- Trả về -1 nếu trùng tên đăng nhập
        RETURN;
    END

    INSERT INTO Users (Username, PasswordHash, FullName, Class, Role)
    VALUES (@Username, @PasswordHash, @FullName, @Class, @Role);

    SELECT SCOPE_IDENTITY() AS Result; -- Trả về ID người dùng mới nếu thành công
END
GO


-- 2. SP CHẤM ĐIỂM VÀ NỘP BÀI THI (Hỗ trợ gọi từ C# MarathonUI)
CREATE PROCEDURE sp_SubmitExam
    @ExamId INT
AS
BEGIN
    DECLARE @TotalQ INT;
    DECLARE @CorrectQ INT;
    DECLARE @FinalScore FLOAT;

    -- Lấy tổng số câu của bài thi
    SELECT @TotalQ = TotalQuestions FROM MarathonExams WHERE ExamId = @ExamId;

    -- Đếm số câu trả lời đúng trong bảng chi tiết
    SELECT @CorrectQ = COUNT(*) 
    FROM ExamDetails 
    WHERE ExamId = @ExamId AND IsCorrect = 1;

    -- Tính điểm hệ 10 (làm tròn 2 chữ số thập phân)
    IF @TotalQ > 0
        SET @FinalScore = ROUND((CAST(@CorrectQ AS FLOAT) / @TotalQ) * 10.0, 2);
    ELSE
        SET @FinalScore = 0.0;

    -- Cập nhật kết quả vào bảng MarathonExams
    UPDATE MarathonExams
    SET EndTime = GETDATE(),
        CorrectAnswers = @CorrectQ,
        Score = @FinalScore,
        IsCompleted = 1
    WHERE ExamId = @ExamId;

    -- Trả về thông tin tổng kết bài thi cho ứng dụng WPF hiển thị
    SELECT @ExamId AS ExamId, @TotalQ AS TotalQuestions, @CorrectQ AS CorrectAnswers, @FinalScore AS Score;
END
GO


-- =========================================================================

-- =========================================================================
-- PHẦN 3: SP TỰ ĐỘNG TRAO HUY HIỆU SAU KHI SINH VIÊN NỘP BÀI
-- Gọi từ WPF: EXEC sp_AwardBadges @UserId, @ExamId
-- Quy tắc: điểm >= 8.0 nhận HUY HIỆU VÀNG (Điểm Giỏi); 10/10 nhận Điểm
-- Hoàn Hảo; hoàn thành 5 bài nhận Kiên Trì; điểm TB >= 8.0 từ 3 bài nhận
-- Học Bá. Chỉ trao huy hiệu CHƯA TỪNG nhận (UQ_User_Badge chống trùng),
-- trả về danh sách huy hiệu MỚI để ứng dụng hiện cửa sổ chúc mừng.
-- =========================================================================
IF OBJECT_ID('sp_AwardBadges', 'P') IS NOT NULL
    DROP PROCEDURE sp_AwardBadges;
GO

CREATE PROCEDURE sp_AwardBadges
    @UserId INT,
    @ExamId INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Completed INT, @Best FLOAT, @Avg FLOAT;

    -- Thong ke cua sinh vien tinh tren cac bai DA NOP (bao gom bai vua nop)
    SELECT @Completed = COUNT(*),
           @Best      = ISNULL(MAX(Score), 0),
           @Avg       = ISNULL(AVG(CAST(Score AS FLOAT)), 0)
    FROM MarathonExams
    WHERE UserId = @UserId AND IsCompleted = 1;

    -- 1. BUOC DAU TIEN: da hoan thanh it nhat 1 bai thi
    IF @Completed >= 1
        INSERT INTO UserBadges (UserId, BadgeId, ExamId)
        SELECT @UserId, b.BadgeId, @ExamId
        FROM Badges b
        WHERE b.BadgeName = N'Bước Đầu Tiên'
          AND NOT EXISTS (SELECT 1 FROM UserBadges x
                          WHERE x.UserId = @UserId AND x.BadgeId = b.BadgeId);

    -- 2. DIEM GIOI (HUY HIEU VANG): dat >= 8.0 diem trong 1 bai thi
    IF @Best >= 8
        INSERT INTO UserBadges (UserId, BadgeId, ExamId)
        SELECT @UserId, b.BadgeId, @ExamId
        FROM Badges b
        WHERE b.BadgeName = N'Điểm Giỏi'
          AND NOT EXISTS (SELECT 1 FROM UserBadges x
                          WHERE x.UserId = @UserId AND x.BadgeId = b.BadgeId);

    -- 3. DIEM HOAN HAO: dat 10/10
    IF @Best >= 10
        INSERT INTO UserBadges (UserId, BadgeId, ExamId)
        SELECT @UserId, b.BadgeId, @ExamId
        FROM Badges b
        WHERE b.BadgeName = N'Điểm Hoàn Hảo'
          AND NOT EXISTS (SELECT 1 FROM UserBadges x
                          WHERE x.UserId = @UserId AND x.BadgeId = b.BadgeId);

    -- 4. KIEN TRI: hoan thanh 5 bai thi
    IF @Completed >= 5
        INSERT INTO UserBadges (UserId, BadgeId, ExamId)
        SELECT @UserId, b.BadgeId, @ExamId
        FROM Badges b
        WHERE b.BadgeName = N'Kiên Trì'
          AND NOT EXISTS (SELECT 1 FROM UserBadges x
                          WHERE x.UserId = @UserId AND x.BadgeId = b.BadgeId);

    -- 5. HOC BA: diem trung binh >= 8.0 voi it nhat 3 bai
    IF @Completed >= 3 AND @Avg >= 8
        INSERT INTO UserBadges (UserId, BadgeId, ExamId)
        SELECT @UserId, b.BadgeId, @ExamId
        FROM Badges b
        WHERE b.BadgeName = N'Học Bá'
          AND NOT EXISTS (SELECT 1 FROM UserBadges x
                          WHERE x.UserId = @UserId AND x.BadgeId = b.BadgeId);

    -- Tra ve cac huy hieu MOI duoc trao trong lan goi nay
    -- (ExamId ghi nhan giup lay dung nhung huy hieu vua trao cho bai thi nay)
    SELECT b.BadgeId, b.BadgeName, b.Description, b.IconUrl, ub.AwardedAt
    FROM UserBadges ub
    JOIN Badges b ON b.BadgeId = ub.BadgeId
    WHERE ub.UserId = @UserId AND ub.ExamId = @ExamId;
END
GO

-- PHẦN 4: THÊM TÀI KHOẢN MẪU (ADMIN VÀ STUDENT)
-- =========================================================================
INSERT INTO Users (Username, PasswordHash, FullName, Class, Role) 
VALUES 
(N'admin', N'123456', N'Quản Trị Viên', NULL, 'Admin'),
(N'student1', N'123456', N'Nguyễn Văn A', N'CNTT01', 'Student');
GO


-- =========================================================================

-- PHẦN 5: THÊM 50 CÂU HỎI VÀ ĐÁP ÁN TRẮC NGHIỆM DSA
-- =========================================================================

-- Câu 1
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Cấu trúc dữ liệu nào hoạt động theo nguyên tắc LIFO (Last In First Out)?', N'Stack & Queue', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Queue (Hàng đợi)', 0), (@@IDENTITY, N'Stack (Ngăn xếp)', 1), (@@IDENTITY, N'Array (Mảng)', 0), (@@IDENTITY, N'Linked List', 0);

-- Câu 2
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Cấu trúc dữ liệu nào hoạt động theo nguyên tắc FIFO (First In First Out)?', N'Stack & Queue', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Stack (Ngăn xếp)', 0), (@@IDENTITY, N'Queue (Hàng đợi)', 1), (@@IDENTITY, N'Tree (Cây)', 0), (@@IDENTITY, N'Graph (Đồ thị)', 0);

-- Câu 3
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Độ phức tạp thời gian trung bình của thuật toán Tìm kiếm nhị phân trên mảng đã sắp xếp là gì?', N'Searching', N'Hiểu');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'O(n)', 0), (@@IDENTITY, N'O(n log n)', 0), (@@IDENTITY, N'O(log n)', 1), (@@IDENTITY, N'O(1)', 0);

-- Câu 4
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Trong cây nhị phân tìm kiếm (BST), tính chất nào sau đây luôn đúng cho mọi nút?', N'BST', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Các nút con bên trái nhỏ hơn nút gốc, các nút con bên phải lớn hơn nút gốc', 1), (@@IDENTITY, N'Nút gốc luôn là nút nhỏ nhất', 0), (@@IDENTITY, N'Cây phải luôn là cây cân bằng', 0), (@@IDENTITY, N'Mọi nút đều có đúng 2 nút con', 0);

-- Câu 5
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Thuật toán sắp xếp nào sau đây dựa trên tư tưởng Chia để trị (Divide and Conquer)?', N'Sorting', N'Hiểu');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Bubble Sort', 0), (@@IDENTITY, N'Insertion Sort', 0), (@@IDENTITY, N'Merge Sort', 1), (@@IDENTITY, N'Selection Sort', 0);

-- Câu 6
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Phép duyệt cây nào đi qua gốc trước, sau đó đến cây con trái rồi đến cây con phải?', N'Tree Traversal', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'In-order', 0), (@@IDENTITY, N'Pre-order', 1), (@@IDENTITY, N'Post-order', 0), (@@IDENTITY, N'BFS', 0);

-- Câu 7
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Thao tác chèn một phần tử vào giữa mảng tĩnh có độ phức tạp thời gian tồi tệ nhất là bao nhiêu?', N'Array', N'Vận dụng');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'O(1)', 0), (@@IDENTITY, N'O(log n)', 0), (@@IDENTITY, N'O(n)', 1), (@@IDENTITY, N'O(n^2)', 0);

-- Câu 8
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Đồ thị có hướng không có chu trình được gọi là gì?', N'Graph', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Đồ thị vô hướng', 0), (@@IDENTITY, N'Đồ thị trọng số', 0), (@@IDENTITY, N'DAG (Directed Acyclic Graph)', 1), (@@IDENTITY, N'Đồ thị đầy đủ', 0);

-- Câu 9
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Cấu trúc dữ liệu nào thường được dùng để cài đặt thuật toán tìm kiếm theo chiều rộng (BFS)?', N'Graph & Queue', N'Hiểu');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Stack', 0), (@@IDENTITY, N'Queue', 1), (@@IDENTITY, N'Heap', 0), (@@IDENTITY, N'Array', 0);

-- Câu 10
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Thuật toán sắp xếp nào có độ phức tạp thời gian xấu nhất là O(n^2) nhưng trung bình là O(n log n)?', N'Sorting', N'Hiểu');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Quick Sort', 1), (@@IDENTITY, N'Merge Sort', 0), (@@IDENTITY, N'Heap Sort', 0), (@@IDENTITY, N'Bubble Sort', 0);

-- Câu 11
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Trong danh sách liên kết đơn (Singly Linked List), mỗi nút chứa tối thiểu thành phần nào?', N'Linked List', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Dữ liệu và con trỏ trỏ tới nút tiếp theo', 1), (@@IDENTITY, N'Chỉ chứa dữ liệu', 0), (@@IDENTITY, N'Dữ liệu và hai con trỏ', 0), (@@IDENTITY, N'Con trỏ về nút trước', 0);

-- Câu 12
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Thứ tự phần tử lấy ra khi thực hiện Push(1), Push(2), Pop(), Push(3), Pop() trên Stack rỗng là gì?', N'Stack & Queue', N'Vận dụng');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'1, 2', 0), (@@IDENTITY, N'2, 3', 1), (@@IDENTITY, N'3, 1', 0), (@@IDENTITY, N'1, 3', 0);

-- Câu 13
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Cây AVL là loại cây gì?', N'BST & AVL', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Cây nhị phân tìm kiếm cân bằng chiều cao', 1), (@@IDENTITY, N'Cây nhị phân hoàn chỉnh', 0), (@@IDENTITY, N'Cây tổng quát', 0), (@@IDENTITY, N'Cây tìm kiếm không có nút lá', 0);

-- Câu 14
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Độ phức tạp thời gian truy cập phần tử theo chỉ số trong mảng (Array) là bao nhiêu?', N'Array', N'Hiểu');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'O(1)', 1), (@@IDENTITY, N'O(log n)', 0), (@@IDENTITY, N'O(n)', 0), (@@IDENTITY, N'O(n^2)', 0);

-- Câu 15
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Thuật toán tìm đường đi ngắn nhất nào áp dụng được cho đồ thị có trọng số cạnh âm (không có chu trình âm)?', N'Graph', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Dijkstra', 0), (@@IDENTITY, N'Bellman-Ford', 1), (@@IDENTITY, N'Prim', 0), (@@IDENTITY, N'Kruskal', 0);

-- Câu 16
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Trong Max Heap, giá trị nút cha luôn thỏa mãn điều kiện gì so với nút con?', N'Heap', N'Hiểu');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Lớn hơn hoặc bằng nút con', 1), (@@IDENTITY, N'Nhỏ hơn hoặc bằng nút con', 0), (@@IDENTITY, N'Luôn bằng nút con', 0), (@@IDENTITY, N'Không quy tắc', 0);

-- Câu 17
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Thuật toán nào dùng để tìm cây khung nhỏ nhất (MST) bằng cách chọn cạnh nhỏ nhất liên tục không tạo chu trình?', N'Graph', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Kruskal', 1), (@@IDENTITY, N'Dijkstra', 0), (@@IDENTITY, N'Floyd-Warshall', 0), (@@IDENTITY, N'DFS', 0);

-- Câu 18
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Hàm băm (Hash Function) tốt có đặc điểm nào sau đây?', N'Hashing', N'Vận dụng');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Phân bố giá trị đồng đều, giảm thiểu xung đột', 1), (@@IDENTITY, N'Tạo nhiều xung đột nhất', 0), (@@IDENTITY, N'Chỉ trả về số âm', 0), (@@IDENTITY, N'Chạy rất chậm', 0);

-- Câu 19
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Phương pháp giải quyết xung đột trong bảng băm bằng cách tạo danh sách liên kết tại mỗi bucket là gì?', N'Hashing', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Chaining', 1), (@@IDENTITY, N'Open Addressing', 0), (@@IDENTITY, N'Linear Probing', 0), (@@IDENTITY, N'Quadratic Probing', 0);

-- Câu 20
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Độ phức tạp không gian của thuật toán đệ quy tính giai thừa với đầu vào n là bao nhiêu?', N'Recursion', N'Hiểu');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'O(n)', 1), (@@IDENTITY, N'O(1)', 0), (@@IDENTITY, N'O(log n)', 0), (@@IDENTITY, N'O(n^2)', 0);

-- Câu 21
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Cấu trúc dữ liệu nào thường dùng để cài đặt thuật toán tìm kiếm theo chiều sâu (DFS)?', N'Graph', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Stack', 1), (@@IDENTITY, N'Queue', 0), (@@IDENTITY, N'Array', 0), (@@IDENTITY, N'Matrix', 0);

-- Câu 22
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Thứ tự thăm của phép duyệt Post-order trên cây nhị phân là gì?', N'Tree Traversal', N'Hiểu');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Trái -> Phải -> Gốc', 1), (@@IDENTITY, N'Gốc -> Trái -> Phải', 0), (@@IDENTITY, N'Trái -> Gốc -> Phải', 0), (@@IDENTITY, N'Phải -> Trái -> Gốc', 0);

-- Câu 23
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Bộ nhớ tiêu tốn của ma trận kề (Adjacency Matrix) với V đỉnh là bao nhiêu?', N'Graph', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'O(V^2)', 1), (@@IDENTITY, N'O(V)', 0), (@@IDENTITY, N'O(V + E)', 0), (@@IDENTITY, N'O(E^2)', 0);

-- Câu 24
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Độ phức tạp tốt nhất của Bubble Sort khi mảng đã được sắp xếp sẵn là bao nhiêu?', N'Sorting', N'Vận dụng');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'O(n)', 1), (@@IDENTITY, N'O(n^2)', 0), (@@IDENTITY, N'O(n log n)', 0), (@@IDENTITY, N'O(1)', 0);

-- Câu 25
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Đặc điểm của Double Linked List so với Single Linked List là gì?', N'Linked List', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Mỗi nút có thêm con trỏ trỏ về nút trước (previous)', 1), (@@IDENTITY, N'Tốn ít bộ nhớ hơn', 0), (@@IDENTITY, N'Không duyệt ngược được', 0), (@@IDENTITY, N'Chỉ chèn cuối', 0);

-- Câu 26
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Thuật toán Dijkstra dùng để làm gì trên đồ thị?', N'Graph', N'Hiểu');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Tìm đường đi ngắn nhất từ một nguồn', 1), (@@IDENTITY, N'Tìm luồng cực đại', 0), (@@IDENTITY, N'Kiểm tra liên thông mạnh', 0), (@@IDENTITY, N'Tìm cây khung nhỏ nhất', 0);

-- Câu 27
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Hiện tượng Stack Overflow trong lập trình xảy ra do nguyên nhân nào?', N'Recursion', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Hàm đệ quy gọi vô hạn lần không có điểm dừng', 1), (@@IDENTITY, N'Dùng quá nhiều biến mảng', 0), (@@IDENTITY, N'Lỗi kết nối CSDL', 0), (@@IDENTITY, N'Đọc file quá lớn', 0);

-- Câu 28
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'BST sẽ bị suy biến thành cấu trúc gì nếu chèn các phần tử có thứ tự tăng dần sẵn?', N'BST', N'Hiểu');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Danh sách liên kết đơn', 1), (@@IDENTITY, N'Cây đầy đủ', 0), (@@IDENTITY, N'Đồ thị đầy đủ', 0), (@@IDENTITY, N'Cây cân bằng', 0);

-- Câu 29
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Thuật toán sắp xếp nào hoạt động giống cách sắp xếp các quân bài trên tay?', N'Sorting', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Insertion Sort', 1), (@@IDENTITY, N'Selection Sort', 0), (@@IDENTITY, N'Merge Sort', 0), (@@IDENTITY, N'Quick Sort', 0);

-- Câu 30
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Cho Queue [10, 20, 30]. Thực hiện Dequeue() một lần rồi Enqueue(40), trạng thái mới là gì?', N'Stack & Queue', N'Vận dụng');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'[20, 30, 40]', 1), (@@IDENTITY, N'[10, 20, 40]', 0), (@@IDENTITY, N'[40, 20, 30]', 0), (@@IDENTITY, N'[30, 20, 10]', 0);

-- Câu 31
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Thuật toán sắp xếp nào tìm phần tử nhỏ nhất đưa về đầu mảng rồi lặp lại?', N'Sorting', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Selection Sort', 1), (@@IDENTITY, N'Bubble Sort', 0), (@@IDENTITY, N'Quick Sort', 0), (@@IDENTITY, N'Insertion Sort', 0);

-- Câu 32
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Độ phức tạp thời gian tìm kiếm tuần tự (Linear Search) trên mảng chưa sắp xếp là bao nhiêu?', N'Searching', N'Hiểu');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'O(n)', 1), (@@IDENTITY, N'O(log n)', 0), (@@IDENTITY, N'O(1)', 0), (@@IDENTITY, N'O(n log n)', 0);

-- Câu 33
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Đồ thị vô hướng có n đỉnh thì số cạnh tối đa là bao nhiêu?', N'Graph', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'(n * (n - 1)) / 2', 1), (@@IDENTITY, N'n * (n - 1)', 0), (@@IDENTITY, N'n^2', 0), (@@IDENTITY, N'n log n', 0);

-- Câu 34
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Trong C#, cấu trúc dữ liệu List<T> dùng cấu trúc gì bên dưới để lưu trữ?', N'Array', N'Hiểu');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Mảng động (Dynamic Array)', 1), (@@IDENTITY, N'Danh sách liên kết kép', 0), (@@IDENTITY, N'Cây nhị phân', 0), (@@IDENTITY, N'Bảng băm', 0);

-- Câu 35
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Chiều cao của cây (Height of Tree) được tính bằng gì?', N'Tree', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Số lượng nút trên đường đi dài nhất từ gốc tới nút lá', 1), (@@IDENTITY, N'Tổng số nút', 0), (@@IDENTITY, N'Số nhánh nút gốc', 0), (@@IDENTITY, N'Số nút lá', 0);

-- Câu 36
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Duyệt In-order trên Cây nhị phân tìm kiếm (BST) sẽ cho ra kết quả các phần tử thế nào?', N'BST', N'Vận dụng');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Thứ tự tăng dần', 1), (@@IDENTITY, N'Thứ tự giảm dần', 0), (@@IDENTITY, N'Ngẫu nhiên', 0), (@@IDENTITY, N'Theo chiều cao', 0);

-- Câu 37
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Thuật toán nào KHÔNG phải là thuật toán sắp xếp dựa trên so sánh?', N'Sorting', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Radix Sort', 1), (@@IDENTITY, N'Merge Sort', 0), (@@IDENTITY, N'Quick Sort', 0), (@@IDENTITY, N'Heap Sort', 0);

-- Câu 38
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Trong danh sách liên kết, chèn một nút mới vào đầu danh sách có độ phức tạp bao nhiêu?', N'Linked List', N'Hiểu');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'O(1)', 1), (@@IDENTITY, N'O(n)', 0), (@@IDENTITY, N'O(log n)', 0), (@@IDENTITY, N'O(n^2)', 0);

-- Câu 39
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Thuật toán Prim dùng để làm gì?', N'Graph', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Tìm cây khung nhỏ nhất (MST)', 1), (@@IDENTITY, N'Tìm đường đi ngắn nhất', 0), (@@IDENTITY, N'Sắp xếp mảng', 0), (@@IDENTITY, N'Kiểm tra chu trình', 0);

-- Câu 40
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Xung đột (Collision) trong bảng băm xảy ra khi nào?', N'Hashing', N'Hiểu');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Hai khóa khác nhau cho ra cùng một chỉ số băm', 1), (@@IDENTITY, N'Bảng băm hết dung lượng', 0), (@@IDENTITY, N'Khóa bằng 0', 0), (@@IDENTITY, N'Hàm băm trả về số âm', 0);

-- Câu 41
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Cây nhị phân đầy đủ (Full Binary Tree) là gì?', N'Tree', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Mọi nút không phải nút lá đều có đúng hai nút con', 1), (@@IDENTITY, N'Tất cả tầng đều đầy', 0), (@@IDENTITY, N'Cây một nhánh', 0), (@@IDENTITY, N'Không có nút lá', 0);

-- Câu 42
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Cây nhị phân hoàn chỉnh chiều cao h có tối đa bao nhiêu nút?', N'Tree', N'Vận dụng');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'2^(h+1) - 1', 1), (@@IDENTITY, N'2^h', 0), (@@IDENTITY, N'h * 2', 0), (@@IDENTITY, N'h^2', 0);

-- Câu 43
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Quy hoạch động (Dynamic Programming) tối ưu hóa bài toán bằng cách nào?', N'Algorithm', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Lưu trữ kết quả các bài toán con đã giải để tránh tính lặp lại', 1), (@@IDENTITY, N'Chọn phương án tốt nhất mỗi bước', 0), (@@IDENTITY, N'Chia bài toán độc lập', 0), (@@IDENTITY, N'Thử tất cả vét cạn', 0);

-- Câu 44
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Độ phức tạp của Heap Sort trong mọi trường hợp là bao nhiêu?', N'Sorting', N'Hiểu');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'O(n log n)', 1), (@@IDENTITY, N'O(n^2)', 0), (@@IDENTITY, N'O(n)', 0), (@@IDENTITY, N'O(log n)', 0);

-- Câu 45
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Trên đồ thị có chu trình âm, thuật toán nào phát hiện được chu trình âm?', N'Graph', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Bellman-Ford', 1), (@@IDENTITY, N'Dijkstra', 0), (@@IDENTITY, N'Prim', 0), (@@IDENTITY, N'Kruskal', 0);

-- Câu 46
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Trong C#, PriorityQueue thường dùng cấu trúc dữ liệu nào bên dưới?', N'Collections', N'Hiểu');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Heap (Đống)', 1), (@@IDENTITY, N'Stack', 0), (@@IDENTITY, N'Array', 0), (@@IDENTITY, N'Linked List', 0);

-- Câu 47
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Điều kiện tiên quyết để chạy thuật toán Tìm kiếm nhị phân là gì?', N'Searching', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Mảng phải được sắp xếp', 1), (@@IDENTITY, N'Số phần tử phải chẵn', 0), (@@IDENTITY, N'Không chứa số âm', 0), (@@IDENTITY, N'Kích thước cố định', 0);

-- Câu 48
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Đồ thị thưa (số cạnh rất ít) nên biểu diễn bằng cấu trúc nào để tiết kiệm bộ nhớ?', N'Graph', N'Vận dụng');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Danh sách kề (Adjacency List)', 1), (@@IDENTITY, N'Ma trận kề', 0), (@@IDENTITY, N'Ma trận trọng số', 0), (@@IDENTITY, N'Mảng 3 chiều', 0);

-- Câu 49
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Phép duyệt BFS trên cây sử dụng cấu trúc phụ trợ nào?', N'Tree Traversal', N'Nhớ');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Queue (Hàng đợi)', 1), (@@IDENTITY, N'Stack', 0), (@@IDENTITY, N'Heap', 0), (@@IDENTITY, N'Vector', 0);

-- Câu 50
INSERT INTO Questions (Content, Topic, BloomLevel) VALUES (N'Cấu trúc dữ liệu tuyến tính nào cho phép thêm và xóa ở cả hai đầu?', N'Stack & Queue', N'Hiểu');
INSERT INTO QuestionOptions (QuestionId, OptionText, IsCorrect) VALUES (@@IDENTITY, N'Deque (Double-ended Queue)', 1), (@@IDENTITY, N'Stack', 0), (@@IDENTITY, N'Queue', 0), (@@IDENTITY, N'Priority Queue', 0);
GO

-- =========================================================================
-- PHẦN 6: SEED DANH MỤC HUY HIỆU (5 HUY HIỆU)
-- IconUrl lưu MÃ ICON - ứng dụng WPF hiển thị emoji + màu sắc tương ứng:
--   first_step / gold_score / perfect / persistent / master
-- =========================================================================
INSERT INTO Badges (BadgeName, Description, IconUrl)
SELECT N'Bước Đầu Tiên', N'Hoàn thành bài thi Marathon đầu tiên', 'first_step'
WHERE NOT EXISTS (SELECT 1 FROM Badges WHERE BadgeName = N'Bước Đầu Tiên');

INSERT INTO Badges (BadgeName, Description, IconUrl)
SELECT N'Điểm Giỏi', N'Đạt từ 8.0 điểm trở lên trong một bài thi', 'gold_score'
WHERE NOT EXISTS (SELECT 1 FROM Badges WHERE BadgeName = N'Điểm Giỏi');

INSERT INTO Badges (BadgeName, Description, IconUrl)
SELECT N'Điểm Hoàn Hảo', N'Đạt điểm tuyệt đối 10/10 trong một bài thi', 'perfect'
WHERE NOT EXISTS (SELECT 1 FROM Badges WHERE BadgeName = N'Điểm Hoàn Hảo');

INSERT INTO Badges (BadgeName, Description, IconUrl)
SELECT N'Kiên Trì', N'Hoàn thành 5 bài thi Marathon', 'persistent'
WHERE NOT EXISTS (SELECT 1 FROM Badges WHERE BadgeName = N'Kiên Trì');

INSERT INTO Badges (BadgeName, Description, IconUrl)
SELECT N'Học Bá', N'Điểm trung bình từ 8.0 trở lên sau ít nhất 3 bài thi', 'master'
WHERE NOT EXISTS (SELECT 1 FROM Badges WHERE BadgeName = N'Học Bá');
GO

-- ==========================================================================
GO

-- =========================================================================
-- PHẦN 7: DỮ LIỆU MẪU (SINH VIÊN + BÀI THI + HUY HIỆU ĐÃ TRAO)
-- Chỉ chạy khi CHƯA có bài thi nào; nếu đã có dữ liệu thật thì TỰ ĐỘNG
-- BỎ QUA để bảo toàn dữ liệu. Giúp THỐNG KÊ / LỊCH SỬ THI / HUY HIỆU có
-- ngay dữ liệu hiển thị. student1 nhận đủ 5/5 huy hiệu (điểm 6.6 -> 10.0).
-- =========================================================================
IF OBJECT_ID('sp_TaoBaiThiMau', 'P') IS NOT NULL
    DROP PROCEDURE sp_TaoBaiThiMau;
GO

-- Thu tuc phu: tao 1 bai thi mau hoan chinh (50 cau ngau nhien, so cau dung
-- dieu khien truoc -> diem = soCauDung * 10 / 50, ghi day du ExamDetails de
-- nut XEM CHI TIET van hoat dong voi du lieu mau)
CREATE PROCEDURE sp_TaoBaiThiMau
    @UserId       INT,
    @StartTime    DATETIME,
    @CorrectCount INT,
    @NewExamId    INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @EndTime DATETIME = DATEADD(MINUTE, 22 + (ABS(CHECKSUM(NEWID())) % 8), @StartTime);

    INSERT INTO MarathonExams (UserId, StartTime, EndTime, TotalQuestions,
                               CorrectAnswers, Score, IsCompleted)
    VALUES (@UserId, @StartTime, @EndTime, 50,
            @CorrectCount, ROUND(@CorrectCount * 10.0 / 50, 2), 1);

    SET @NewExamId = SCOPE_IDENTITY();

    ;WITH Chon AS (
        SELECT TOP 50 q.QuestionId, q.BloomLevel,
               ROW_NUMBER() OVER (ORDER BY NEWID()) AS rn
        FROM Questions q
    )
    INSERT INTO ExamDetails (ExamId, QuestionId, SelectedOptionId, IsCorrect, BloomLevel)
    SELECT @NewExamId,
           c.QuestionId,
           (SELECT TOP 1 o.OptionId
            FROM QuestionOptions o
            WHERE o.QuestionId = c.QuestionId
              AND o.IsCorrect = CASE WHEN c.rn <= @CorrectCount THEN 1 ELSE 0 END
            ORDER BY NEWID()),
           CASE WHEN c.rn <= @CorrectCount THEN 1 ELSE 0 END,
           c.BloomLevel
    FROM Chon c;
END
GO

IF NOT EXISTS (SELECT 1 FROM MarathonExams)
   AND EXISTS (SELECT 1 FROM Users WHERE Username = 'student1')
BEGIN
    DECLARE @Uid1 INT, @Uid2 INT, @Uid3 INT, @Uid4 INT, @ExamId INT;

    SELECT @Uid1 = UserId FROM Users WHERE Username = 'student1';
    SELECT @Uid2 = UserId FROM Users WHERE Username = 'student2';
    SELECT @Uid3 = UserId FROM Users WHERE Username = 'student3';
    SELECT @Uid4 = UserId FROM Users WHERE Username = 'student4';

    -- Them 3 sinh vien mau neu chua ton tai (mat khau 123456)
    IF @Uid2 IS NULL
    BEGIN
        INSERT INTO Users (Username, PasswordHash, FullName, Class, Role)
        VALUES ('student2', '123456', N'Trần Thị B', 'CNTT01', 'Student');
        SELECT @Uid2 = UserId FROM Users WHERE Username = 'student2';
    END

    IF @Uid3 IS NULL
    BEGIN
        INSERT INTO Users (Username, PasswordHash, FullName, Class, Role)
        VALUES ('student3', '123456', N'Lê Văn C', 'CNTT02', 'Student');
        SELECT @Uid3 = UserId FROM Users WHERE Username = 'student3';
    END

    IF @Uid4 IS NULL
    BEGIN
        INSERT INTO Users (Username, PasswordHash, FullName, Class, Role)
        VALUES ('student4', '123456', N'Phạm Thị D', 'CNTT02', 'Student');
        SELECT @Uid4 = UserId FROM Users WHERE Username = 'student4';
    END

    -- ===== student1: 5 bai (6.6 -> 7.8 -> 8.4 -> 9.2 -> 10.0, TB = 8.4) =====
    -- => nhan du 5/5 huy hieu: Buoc Dau Tien, Diem Gioi, Diem Hoan Hao, Kien Tri, Hoc Ba
    EXEC sp_TaoBaiThiMau @Uid1, DATEADD(DAY, -14, GETDATE()), 33, @ExamId OUTPUT;
    EXEC sp_TaoBaiThiMau @Uid1, DATEADD(DAY, -11, GETDATE()), 39, @ExamId OUTPUT;
    EXEC sp_TaoBaiThiMau @Uid1, DATEADD(DAY, -8,  GETDATE()), 42, @ExamId OUTPUT;
    EXEC sp_TaoBaiThiMau @Uid1, DATEADD(DAY, -5,  GETDATE()), 46, @ExamId OUTPUT;
    EXEC sp_TaoBaiThiMau @Uid1, DATEADD(DAY, -2,  GETDATE()), 50, @ExamId OUTPUT;
    EXEC sp_AwardBadges @Uid1, @ExamId;   -- trao huy hieu theo bai moi nhat

    -- ===== student2: 2 bai (6.0, 7.4) => chi nhan Buoc Dau Tien =====
    EXEC sp_TaoBaiThiMau @Uid2, DATEADD(DAY, -7, GETDATE()), 30, @ExamId OUTPUT;
    EXEC sp_TaoBaiThiMau @Uid2, DATEADD(DAY, -3, GETDATE()), 37, @ExamId OUTPUT;
    EXEC sp_AwardBadges @Uid2, @ExamId;

    -- ===== student3: 1 bai (8.2) => Buoc Dau Tien + Diem Gioi =====
    EXEC sp_TaoBaiThiMau @Uid3, DATEADD(DAY, -1, GETDATE()), 41, @ExamId OUTPUT;
    EXEC sp_AwardBadges @Uid3, @ExamId;

    -- ===== student4: chua thi => 0 huy hieu (hien trang khoa tren UI) =====

    PRINT N'Da tao du lieu mau: 3 sinh vien + 8 bai thi + chi tiet + huy hieu.';
END
ELSE
BEGIN
    PRINT N'CSDL da co du lieu thi that -> bo qua phan du lieu mau (khong them gi).';
END
GO

-- Don dep thu tuc phu sau khi tao du lieu mau
IF OBJECT_ID('sp_TaoBaiThiMau', 'P') IS NOT NULL
    DROP PROCEDURE sp_TaoBaiThiMau;
GO

-- =========================================================================
-- PHẦN 8: KIỂM TRA KẾT QUẢ (KHÔNG BẮT BUỘC - XEM NHANH SỐ NGƯỜI NHẬN HUY HIỆU)
-- =========================================================================
SELECT b.BadgeId, b.BadgeName, b.IconUrl, COUNT(ub.UserBadgeId) AS SoNguoiNhan
FROM Badges b
LEFT JOIN UserBadges ub ON ub.BadgeId = b.BadgeId
GROUP BY b.BadgeId, b.BadgeName, b.IconUrl
ORDER BY b.BadgeId;
GO

SELECT *
FROM UserBadges